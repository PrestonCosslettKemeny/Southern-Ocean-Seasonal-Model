A seasonal model of nitrogen isotopes in the ice age Antarctic Zone: Support for weakening of the Southern Ocean upper overturning cell

P.C. Kemeny (a,b)*, E.R. Kast (a), M.P. Hain (c,d), S.E. Fawcett (e), F. Fripiat (f), A.S. Studer (f), A. Martínez-García (f), G.H. Haug (f), D.M. Sigman (a)

a Department of Geosciences, Princeton University, Princeton, New Jersey, USA
b Division of Geological and Planetary Sciences, California Institute of Technology, Pasadena, California, USA
c Ocean and Earth Science, University of Southampton, Southampton, United Kingdom
d Department of Earth and Planetary Sciences, University of California Santa Cruz, Santa Cruz, California, USA
e Department of Oceanography, University of Cape Town, Rondebosch, South Africa
f Max Planck Institute for Chemistry, Climate Geochemistry Department, Mainz, Germany
*pkemeny@caltech.edu 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

This file provides a brief introduction to the Matlab files associated with the Southern Ocean seasonal model.

GENERAL TIPS & ADVICE: 
- When opening the model for the first time, start with the file SOM_MasterScript.
- Switching between running code on multiple processors or a single processor only entails switching the main "for" loop of the code to be a "parfor" loop. To do so, comment out line 231 and 232, then uncomment lines 235 and 236.  
- The model can be run at either high resolution or low resolution. The difference is the relative and absolute error tolerances of the ODE solver, which are defined in SOM_RunModel. Resolution does not relate to the number of model runs or the number of data points produced. Running the model in high-resolution will take longer than running the model in low resolution. 
- Control the number of simulations by changing the length of the fineset vector. Control the data points returned by changing the time points in SOM_RunModel (the variable T).
- The model contains several performance checks, including continuously monitoring for mass balance in the function SOM_TestMassConservation. Take seriously any warnings returned when the model is run in high-resolution mode.
- To run a new simulation (see below), define the basic model fluxes in SOM_ParameterInputX file, choose how that behavior should be varied by defining coefficients in the fineset vector and SOM_FindIterationVariables, then select to run the simulation in SOM_MasterScript.
- To add new model reservoirs or fluxes, define the initial condition of the new reservoirs in SOM_InitialConditions, define the flux laws in SOM_SeasonalModel, describe how to process the new model results in SOM_OrganizeModelResults, and add the new reservoirs to SOM_TestMassConservation to ensure the model is still in mass balance.
- The model data organized into multiple structures: output, all of the data from the simulation; steady, all of the data from the steady-state year; allendssn, the end-season data from every year; endssn, the end-season data from the steady-state year.


FILES TO RUN THE MODEL (roughly in the order in which they are called): 
SOM_MasterScript: Master script for the entire model. This script calls on functions that define one or multiple model simulation, runs the model, and saves the output. 
SOM_FindIterationVariables: Find the parameters of model simulations. Each element of each vector is a coefficient to be multiplied by the basic parameter value defined in SOM_ParameterInputX. This can be confusing because several iterations call on the variable fineset, which is actually defined in SOM_MasterScript. 
SOM_ParameterInputX: Define the flux coefficients and basic model parameters, called in SOM_GenerateInputs.
SOM_GenerateInputs: Generate the basic input parameters defined in SOM_ParameterInputX. These parameter values will be multiplied by the coefficients chosen in SOM_FindIterationVariables to reach the actual parameters used in each model simulation. 
SOM_UpdateInputParameters: Update the input parameters from SOM_GenerateInputs by the scalars defined in SOM_FindIterationVariables. Depending on the chosen simulation, only certain variables will be updated.
SOM_RunModel: Run the model and evaluates whether model results are acceptable.
SOM_InitialConditions: Define the initial conditions of the ODE solver. 
SOM_SeasonalModel: The actual differential equations that define the seasonal model. These equations are given in symbolic format in supplement S1 of Kemeny et al. 
SOM_CalculateInputVariables: Break down the structure "MI" into usable variables. 
SOM_DeclareVariableIndex: Declare a characteristic index for each model variable. 
SOM_Calculate15NFlux: Calculate the flux of 15 for a given flux of 14N, the abundance of 14N and 15N in the reacting reservoirs, and the fractionation factor of the process. The equation in this files is derived from Hayes (2004) and calculates the heavy isotope flux without approximation given the flux of the light isotope, the abundance of heavy and light isotope in the reacting reservoir, and the isotope effect of the process.
SOM_OrganizeModelResults: Organize the raw model output into structures of interest (model variable values at the conclusion of seasons, during the steady-state year, etc.)
SOM_TestMassConservation: Test whether the model obeyed mass balance throughout the run. If adding new reservoirs to the model, they have to be included in this function or the system will report being out of mass balance.
SOM_UpdateResults: Updates the results structure when running multiple model simulations. 


DEFINING A NEW MODEL SCENARIO: 
Invent a descriptive name (for example, 'MyScenario') for the scenario and put it into IterationList in SOM_MasterScript. In SOM_FineIterationVariables, make a new entry under the primary if loop, which would be: elseif isequal(activesimulation,'MyScenario'). Within this elseif statement, supply values to the vectors EkmanFactor, BoundaryFactor, KwFactor, CDWFactor, and MLDFactor. Each value of these vectors defines a multiplier that will scale the corresponding variable of the basic model inputs, which are defined in the SOM_ParameterInputX file. If all of these vectors have only 1 entry, the code will run the model once. If all vectors have n entries, the model will run n times with the nth simulation having the model parameters corresponding to the nth entry of each vector. If the vectors have different numbers of entries, there is a series of if statement in SOM_MasterScript to decide how to proceed (the model will return errors if it does not explicitly know how to treat the input parameters). If EkmanFactor, BoundaryFactor, or both are long and the other variables have only one value, the other variables are taken to equal their one given value in all simulations. Additionally, provide the new simulation with an InputTitleNumber, which tells the program what number to append to "ParameterInput" when generating the basic set of model variables, and helps to save model output with a distinctive file name. Lastly, choose either a 0 or 1 for RunNCycle and FullyIterate, which respectively determine whether the model should run with a N cycle and whether the model should test every combination of model parameters. For convenience, StandardInputTitleNumber and fineset are both defined in SOM_MasterScript. In SOM_MasterScript, choose the desired model resolution and whether the model should be run on a single processor or in parallel. Then run the function SOM_MasterScript. As it runs, the code will display whether it found variables for each entry in IterationList, the chosen resolution, and whether the model run was successful. The model saves a datafile for each entry in IterationList. When running a single iteration, the model saves all output. When running a series of simulations, the model only saves a subset of results (otherwise the output files would be multiple gigabytes each). 

