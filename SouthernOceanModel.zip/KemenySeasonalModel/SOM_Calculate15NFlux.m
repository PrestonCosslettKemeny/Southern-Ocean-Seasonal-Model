function N15Flux = SOM_Calculate15NFlux(m14Nr0,m15Nr0,dm14Np,alpha)

% This function calculates a 15N flux given the 14N and 15N of the 
% reactant pool, the flux of 14N (d14N), and the isotope effect of
% the reaction. This funciton is based on equation 33 of Hayes [2004].

% This equation returns the flux of 15N to the product. 
% In an expression for a reactant pool, SUBTRACT THIS VALUE.
% In an expression for a product pool, ADD THIS VALUE.

if dm14Np==0
    N15Flux = 0;
else     
    
    % This equation is the exact solution for a given change:
    N15Flux = m15Nr0 - m15Nr0*(((m14Nr0-dm14Np)/m14Nr0)^alpha);          
    
end
end





