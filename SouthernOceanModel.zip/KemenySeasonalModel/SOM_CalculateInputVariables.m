% TEMPORAL AND SPATIAL PARAMETERS
   ModelLength                     = MI.ModelLength;                       % (years) - The length of the model 
   SummerSeason                    = MI.SummerSeason;                      % (days) - The number of summertime days each year 
   WinterSeason                    = MI.WinterSeason;                      % (days) - The number of wintertime days each year 
   ANZArea                         = MI.ANZArea;                           % (m^2) - The area of the Open Antarctic Zone (OAZ)
   MLDSummer                       = MI.MLDSummer;                         % (m) WinterMixTmnSrfWinter- MLD of the OAZ during summer
   MLDWinter                       = MI.MLDWinter;                         % (m) - MLD of the OAZ during winter
% BOUNDARY CONDITIONS 
   CDWN14                          = MI.CDWN14;                            % (uM) - 14N in UCDW (boundary condition)
   CDWN15                          = MI.CDWN15;                            % (uM) - 15N in UCDW (boundary condition)
   CDWd15N                         = MI.CDWd15N;                           % (per mil) - d15N of UCDW (boundary condition)
% VERTICAL MIXING
   EkmanCDWTransport               = MI.EkmanCDWTransport;                 % (m^3/day) - NO3 Summertime vertical Ekman transport
   MixTmnCDWBnd                    = MI.MixTmnCDWBnd;                      % (m^3/day) - NO3 Tmin-UCDW boundary mixing
   MixTmnSrfWinter                 = MI.MixTmnSrfWinter;                   % (m^3/day) - NO3 Tmin-Surface mixing during wintertime
   MixTmnSrfSummer                 = MI.MixTmnSrfSummer;                   % (m^3/day) - NO3 Tmin-Surface mixing during summertime
% GENERAL
   BiomassRemineralizationFraction = MI.BiomassRemineralizationFraction;   % (%) - Fraction of dead diatoms remineralization in Tmin
   BiomassRemineralizationEpsilon  = MI.BiomassRemineralizationEpsilon;    % (%) - Epsilon of dead diatoms remineralization in Tmin
% DIATOMS
   DtmKnNO3                        = MI.DtmKnNO3;                          % (uM) - Diatom NO3 1/2 consumption constant in MM kinetics (denominator)
   DtmFrustFrac                    = MI.DtmFrustFrac;                      % (uM) - Diatom NO3 1/2 consumption constant in MM kinetics (denominator)
   DtmVmax                         = MI.DtmVmax;                           % (uM) -Diatom consuption term in MM kinetics (numerator)
   DtmNO3UptakeEpsilon             = MI.DtmNO3UptakeEpsilon;               % (per mil) - Diatom NO3 assimilation isotope effect
   DtmSink                         = MI.DtmSink;
   DtmGrowDayStart                 = MI.DtmGrowDayStart;                   % (days) - Number of days centric diatoms grow
   DtmGrowDayEnd                   = MI.DtmGrowDayEnd;                     % (days) - Number of days centric diatoms grow
% ZOOPLANKTON   
   ZooConsumptionDtm               = MI.ZooConsumptionDtm;                 % (%) - Rate at which zooplankton consume diatoms
   ZooConsumptionEpsilon           = MI.ZooConsumptionEpsilon;             % (per mil) - Isotope effect with which zooplankton consume diatoms
   ZooConsumptionNDm               = MI.ZooConsumptionNDm;                 % Consumption of non-diatoms by zooplankton
   ZooDigestiveFraction            = MI.ZooDigestiveFraction;              % (%) - Fraction of food to zooplankton metabolized into biomass
   ZooDigestiveEpsilon             = MI.ZooDigestiveEpsilon;               % (%) - Fraction of food to zooplankton metabolized into biomass
% NON-DIATOM PHYTOPLANKTON 
   NDmNH4ConsumptionSummer         = MI.NDmNH4ConsumptionSummer;           % (%) - Rate at which non-diatom phytoplankton uptake NH4
   NDmUptakeEpsilon                = MI.NDmUptakeEpsilon;                  % (per mil) -  Isotope effect with which non-diatom phytoplankton uptake NH4
   NDmToNH4                        = MI.NDmToNH4;
% AMMONIUM 
   ZooNH4Production                = MI.ZooNH4Production;                  % Rate of NH4 production from zooplankton (first order)
   ZooNH4ProductionEpsilon         = MI.ZooNH4ProductionEpsilon;           % Isotope effect of NH4 production from zooplankton
   NH4SrfRenitrificationSummer     = MI.NH4SrfRenitrificationSummer;       % Rate of NH4 nitrification during winter (first order)
   NH4SrfRenitrificationWinter     = MI.NH4SrfRenitrificationWinter;       % Rate of NH4 nitrification during winter (first order)
   NH4TmnRenitrification           = MI.NH4TmnRenitrification;             % Rate of NH4 nitrification during winter (first order)
   NH4NitrificationEpsilon         = MI.NH4NitrificationEpsilon;           % Isotope effect of NH4 nitrification 
% OTHER
   Rair                            = MI.Rair;                              % Ratio of 15N/14N in atmospheric N2 (reference material)
   
   
%% VARIABLES DEFINED BY CALCULATION
TmnANZHeight                       = MLDWinter-MLDSummer;                  % (m) - Depth of the Tmn layer
SrfVol                             = ANZArea*MLDSummer;                    % (m^3) Volume of surface box
TmnVol                             = ANZArea*TmnANZHeight;                 % (m^3) Volume of Tmin box
Rair = .0036765;     

DtmNO3UptakeAlpha                  = DtmNO3UptakeEpsilon/1000+1;
NDmUptakeAlpha                     = NDmUptakeEpsilon/1000+1;              % (-) - Fractionation factor of non-diatom phytoplankton uptaking NH4 
ZooConsumptionAlphaDtm             = ZooConsumptionEpsilon/1000+1;         % (-) - Fractionation factor of zooplankton consuming diatoms
ZooNH4ProductionAlpha              = ZooNH4ProductionEpsilon/1000+1;       % (-) - Fractionation factor of zooplankton producing NH4
NH4NitrificationAlpha              = NH4NitrificationEpsilon/1000+1;       % (-) - Fractionation factor of NH4 nitrification
ZooDigestiveAlpha                  = ZooDigestiveEpsilon/1000+1;           % (-) - Fractionation factor of zooplankton metabolism
BiomassRemineralizationAlpha       = BiomassRemineralizationEpsilon/1000+1;% (-) - Fractionation factor of biomass remineralization
