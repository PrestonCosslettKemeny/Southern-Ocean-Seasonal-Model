% This script defines the paramters of the chosen model. For each of
% several variables (Ekman upwelling, basal mixing Monod parameterization 
% Kw, the concentration of CDW NO3, and MLD) the script defines either 
% a scaler or a vector of values. These values are then used in 
% ODE_MasterScript to update the default values defined in the
% ODE_ParameterInputX files, where X = InputTitleNumber. This script works
% for both single-run model iterations and for defining multiple values
% over which to iterate. The choices of factors are defined fractionally,
% often relative to the vector "fineset" defined in the MasterScript.

% Identify the default amount of mixing detailed in the input parameters
Ek0 = 20; BM0 = 20;

% StandardInterglacial_Ek
    if isequal(activesimulation,'StandardInterglacial_Ek')
EkmanFactor = 1; BoundaryFactor = 0; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1;  
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardInterglacial_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardInterglacial_BM
    elseif isequal(activesimulation,'StandardInterglacial_BM')
EkmanFactor = 0; BoundaryFactor = 1; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardInterglacial_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardInterglacial_Mix
    elseif isequal(activesimulation,'StandardInterglacial_Mix')
EkmanFactor = 0.5; BoundaryFactor = 0.5; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardInterglacial_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardInterglacial_Mix_Remineralization
    elseif isequal(activesimulation,'StandardInterglacial_Mix_Remineralization')
EkmanFactor = 0.5; BoundaryFactor = 0.5; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = RemineralizationInputTitleNumber;
SaveName = {[['StandardInterglacial_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardInterglacial_Mix_ReduceMLDTogether50
    elseif isequal(activesimulation,'StandardInterglacial_Mix_ReduceMLDTogether50')
MLDmin = 50; MLDstart = 50;
EkmanFactor = 0.5; BoundaryFactor = 0.5; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*1)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardInterglacial_Mix_ReduceMLDTogether50_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardInterglacial_Mix_ReduceMLDTogether25
    elseif isequal(activesimulation,'StandardInterglacial_Mix_ReduceMLDTogether25')
MLDmin = 25; MLDstart = 50;
EkmanFactor = 0.5; BoundaryFactor = 0.5; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*1)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardInterglacial_Mix_ReduceMLDTogether25_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardInterglacial_Mix_ReduceMLDTogether10
    elseif isequal(activesimulation,'StandardInterglacial_Mix_ReduceMLDTogether10')
MLDmin = 10; MLDstart = 50;
EkmanFactor = 0.5; BoundaryFactor = 0.5; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*1)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardInterglacial_Mix_ReduceMLDTogether10_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardInterglacial_Mix_ReduceMLDSummerOnly50
    elseif isequal(activesimulation,'StandardInterglacial_Mix_ReduceMLDSummerOnly50')
MLDmin = 50; MLDstart = 50;
EkmanFactor = 0.5; BoundaryFactor = 0.5; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*1)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 0;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardInterglacial_Mix_ReduceMLDSummerOnly50_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardInterglacial_Mix_ReduceMLDSummerOnly25
    elseif isequal(activesimulation,'StandardInterglacial_Mix_ReduceMLDSummerOnly25')
MLDmin = 25; MLDstart = 50;
EkmanFactor = 0.5; BoundaryFactor = 0.5; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*1)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 0;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardInterglacial_Mix_ReduceMLDSummerOnly25_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardInterglacial_Mix_ReduceMLDSummerOnly10
    elseif isequal(activesimulation,'StandardInterglacial_Mix_ReduceMLDSummerOnly10')
MLDmin = 10; MLDstart = 50;
EkmanFactor = 0.5; BoundaryFactor = 0.5; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*1)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 0;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardInterglacial_Mix_ReduceMLDSummerOnly10_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};



% CoarseFullyIteratedNCycle
    elseif isequal(activesimulation,'CoarseFullyIteratedNCycle')
EkmanFactor = coarseset; BoundaryFactor = coarseset; 
FullyIterate = 1; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['CoarseFullyIteratedNCycle_PI' InputTitleNumber '_' num2str(Ek0*max(EkmanFactor)) 'Ek' num2str(BM0*max(BoundaryFactor)) 'BM']]};


% CoarseFullyIteratedNoNCycle
    elseif isequal(activesimulation,'CoarseFullyIteratedNoNCycle')
EkmanFactor = coarseset; BoundaryFactor = coarseset; 
FullyIterate = 1; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['CoarseFullyIteratedNoNCycle_PI' InputTitleNumber '_' num2str(Ek0*max(EkmanFactor)) 'Ek' num2str(BM0*max(BoundaryFactor)) 'BM']]};


% StandardMidglacial_Ek
    elseif isequal(activesimulation,'StandardMidglacial_Ek')
EkmanFactor = 0.20; BoundaryFactor = 0.0; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1;  
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardMidglacial_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardMidglacial_BM
    elseif isequal(activesimulation,'StandardMidglacial_BM')
EkmanFactor = 0.0; BoundaryFactor = 0.20; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardMidglacial_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardMidglacial_Mix
    elseif isequal(activesimulation,'StandardMidglacial_Mix')
EkmanFactor = 0.20/2; BoundaryFactor = 0.20/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardMidglacial_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardMidglacial_Mix_ReduceMLDTogether50
    elseif isequal(activesimulation,'StandardMidglacial_Mix_ReduceMLDTogether50')
MLDmin = 50; MLDstart = 50;
EkmanFactor = 0.20/2; BoundaryFactor = 0.20/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*0.20)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardMidglacial_Mix_ReduceMLDTogether50_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardMidglacial_Mix_ReduceMLDTogether25
    elseif isequal(activesimulation,'StandardMidglacial_Mix_ReduceMLDTogether25')
MLDmin = 25; MLDstart = 50;
EkmanFactor = 0.20/2; BoundaryFactor = 0.20/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*0.20)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardMidglacial_Mix_ReduceMLDTogether25_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardMidglacial_Mix_ReduceMLDTogether10
    elseif isequal(activesimulation,'StandardMidglacial_Mix_ReduceMLDTogether10')
MLDmin = 10; MLDstart = 50;
EkmanFactor = 0.20/2; BoundaryFactor = 0.20/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*0.20)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardMidglacial_Mix_ReduceMLDTogether10_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};

%StandardMidglacial_Mix_ReduceMLDSummerOnly50
    elseif isequal(activesimulation,'StandardMidglacial_Mix_ReduceMLDSummerOnly50')
MLDmin = 50; MLDstart = 50;
EkmanFactor = 0.20/2; BoundaryFactor = 0.20/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*0.20)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 0;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardMidglacial_Mix_ReduceMLDSummerOnly50_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardMidglacial_Mix_ReduceMLDSummerOnly25
    elseif isequal(activesimulation,'StandardMidglacial_Mix_ReduceMLDSummerOnly25')
MLDmin = 25; MLDstart = 50;
EkmanFactor = 0.20/2; BoundaryFactor = 0.20/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*0.20)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 0;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardMidglacial_Mix_ReduceMLDSummerOnly25_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardMidglacial_Mix_ReduceMLDSummerOnly10
    elseif isequal(activesimulation,'StandardMidglacial_Mix_ReduceMLDSummerOnly10')
MLDmin = 10; MLDstart = 50;
EkmanFactor = 0.20/2; BoundaryFactor = 0.20/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*0.20)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 0;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardMidglacial_Mix_ReduceMLDSummerOnly10_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardGlacial_Ek
    elseif isequal(activesimulation,'StandardGlacial_Ek')
EkmanFactor = 0.05;  BoundaryFactor = 0.00;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardGlacial_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardGlacial_BM
    elseif isequal(activesimulation,'StandardGlacial_BM')
EkmanFactor = 0.00; BoundaryFactor = 0.05; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardGlacial_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardGlacial_Mix
    elseif isequal(activesimulation,'StandardGlacial_Mix')
EkmanFactor = 0.05/2; BoundaryFactor = 0.05/2; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardGlacial_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardGlacial_Mix_ReduceMLDTogether50
    elseif isequal(activesimulation,'StandardGlacial_Mix_ReduceMLDTogether50')
MLDmin = 50; MLDstart = 50;
EkmanFactor = 0.05/2; BoundaryFactor = 0.05/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*0.05)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardGlacial_Mix_ReduceMLDTogether50_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardGlacial_Mix_ReduceMLDTogether25
    elseif isequal(activesimulation,'StandardGlacial_Mix_ReduceMLDTogether25')
MLDmin = 25; MLDstart = 50;
EkmanFactor = 0.05/2; BoundaryFactor = 0.05/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*0.05)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardGlacial_Mix_ReduceMLDTogether25_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardGlacial_Mix_ReduceMLDTogether10
    elseif isequal(activesimulation,'StandardGlacial_Mix_ReduceMLDTogether10')
MLDmin = 10; MLDstart = 50;
EkmanFactor = 0.05/2; BoundaryFactor = 0.05/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*0.05)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardGlacial_Mix_ReduceMLDTogether10_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardGlacial_Mix_ReduceMLDSummerOnly50
    elseif isequal(activesimulation,'StandardGlacial_Mix_ReduceMLDSummerOnly50')
MLDmin = 50; MLDstart = 50;
EkmanFactor = 0.05/2; BoundaryFactor = 0.05/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*0.05)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 0;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardGlacial_Mix_ReduceMLDSummerOnly50_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardGlacial_Mix_ReduceMLDSummerOnly25
    elseif isequal(activesimulation,'StandardGlacial_Mix_ReduceMLDSummerOnly25')
MLDmin = 25; MLDstart = 50;
EkmanFactor = 0.05/2; BoundaryFactor = 0.05/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*0.05)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 0;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardGlacial_Mix_ReduceMLDSummerOnly25_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% StandardGlacial_Mix_ReduceMLDSummerOnly10
    elseif isequal(activesimulation,'StandardGlacial_Mix_ReduceMLDSummerOnly10')
MLDmin = 10; MLDstart = 50;
EkmanFactor = 0.05/2; BoundaryFactor = 0.05/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*0.05)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 0;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['StandardGlacial_Mix_ReduceMLDSummerOnly10_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleInterglacial_Mix    
    elseif isequal(activesimulation,'NoNCycleInterglacial_Mix')
EkmanFactor = 0.5; BoundaryFactor = 0.5; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleInterglacial_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleInterglacial_Ek
    elseif isequal(activesimulation,'NoNCycleInterglacial_Ek')
EkmanFactor = 1; BoundaryFactor = 0; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0;
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleInterglacial_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleInterglacial_BM
    elseif isequal(activesimulation,'NoNCycleInterglacial_BM')
EkmanFactor = 0; BoundaryFactor = 1;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleInterglacial_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleInterglacial_Mix_ReduceMLDTogether50
    elseif isequal(activesimulation,'NoNCycleInterglacial_Mix_ReduceMLDTogether50')
MLDmin = 50; MLDstart = 50;
EkmanFactor = 0.5; BoundaryFactor = 0.5; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*1)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleInterglacial_Mix_ReduceMLDTogether50_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleInterglacial_Mix_ReduceMLDTogether25
    elseif isequal(activesimulation,'NoNCycleInterglacial_Mix_ReduceMLDTogether25')
MLDmin = 25; MLDstart = 50;
EkmanFactor = 0.5; BoundaryFactor = 0.5; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*1)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleInterglacial_Mix_ReduceMLDTogether25_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleInterglacial_Mix_ReduceMLDTogether10
    elseif isequal(activesimulation,'NoNCycleInterglacial_Mix_ReduceMLDTogether10')
MLDmin = 10; MLDstart = 50;
EkmanFactor = 0.5; BoundaryFactor = 0.5; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*1)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleInterglacial_Mix_ReduceMLDTogether10_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};

% NoNCycleInterglacial_Mix_ReduceMLDSummerOnly50
    elseif isequal(activesimulation,'NoNCycleInterglacial_Mix_ReduceMLDSummerOnly50')
MLDmin = 50; MLDstart = 50;
EkmanFactor = 0.5; BoundaryFactor = 0.5; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*1)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 0;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleInterglacial_Mix_ReduceMLDSummerOnly50_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleInterglacial_Mix_ReduceMLDSummerOnly25
    elseif isequal(activesimulation,'NoNCycleInterglacial_Mix_ReduceMLDSummerOnly25')
MLDmin = 25; MLDstart = 50;
EkmanFactor = 0.5; BoundaryFactor = 0.5; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*1)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 0;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleInterglacial_Mix_ReduceMLDSummerOnly25_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleInterglacial_Mix_ReduceMLDSummerOnly10
    elseif isequal(activesimulation,'NoNCycleInterglacial_Mix_ReduceMLDSummerOnly10')
MLDmin = 10; MLDstart = 50;
EkmanFactor = 0.5; BoundaryFactor = 0.5; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*1)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 0;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleInterglacial_Mix_ReduceMLDSummerOnly10_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleMidglacial_Mix
    elseif isequal(activesimulation,'NoNCycleMidglacial_Mix')
EkmanFactor = 0.20/2; BoundaryFactor = 0.20/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0;
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleMidglacial_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleMidglacial_Ek
    elseif isequal(activesimulation,'NoNCycleMidglacial_Ek')
EkmanFactor = 0.20; BoundaryFactor = 0;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleMidglacial_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleMidglacial_BM
    elseif isequal(activesimulation,'NoNCycleMidglacial_BM')
EkmanFactor = 0; BoundaryFactor = 0.20; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleMidglacial_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleMidglacial_Mix_ReduceMLDTogether50
    elseif isequal(activesimulation,'NoNCycleMidglacial_Mix_ReduceMLDTogether50')
MLDmin = 50; MLDstart = 50;
EkmanFactor = 0.20/2; BoundaryFactor = 0.20/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*0.20)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleMidglacial_Mix_ReduceMLDTogether50_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleMidglacial_Mix_ReduceMLDTogether25
    elseif isequal(activesimulation,'NoNCycleMidglacial_Mix_ReduceMLDTogether25')
MLDmin = 25; MLDstart = 50;
EkmanFactor = 0.20/2; BoundaryFactor = 0.20/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*0.2)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleMidglacial_Mix_ReduceMLDTogether25_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleMidglacial_Mix_ReduceMLDTogether10
    elseif isequal(activesimulation,'NoNCycleMidglacial_Mix_ReduceMLDTogether10')
MLDmin = 10; MLDstart = 50;
EkmanFactor = 0.20/2; BoundaryFactor = 0.20/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*0.20)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleMidglacial_Mix_ReduceMLDTogether10_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};

% NoNCycleMidglacial_Mix_ReduceMLDSummerOnly50
    elseif isequal(activesimulation,'NoNCycleMidglacial_Mix_ReduceMLDSummerOnly50')
MLDmin = 50; MLDstart = 50;
EkmanFactor = 0.20/2; BoundaryFactor = 0.20/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*0.20)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 0;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleMidglacial_Mix_ReduceMLDSummerOnly50_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleMidglacial_Mix_ReduceMLDSummerOnly25
    elseif isequal(activesimulation,'NoNCycleMidglacial_Mix_ReduceMLDSummerOnly25')
MLDmin = 25; MLDstart = 50;
EkmanFactor = 0.20/2; BoundaryFactor = 0.20/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*0.2)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 0;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleMidglacial_Mix_ReduceMLDSummerOnly25_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleMidglacial_Mix_ReduceMLDSummerOnly10
    elseif isequal(activesimulation,'NoNCycleMidglacial_Mix_ReduceMLDSummerOnly10')
MLDmin = 10; MLDstart = 50;
EkmanFactor = 0.20/2; BoundaryFactor = 0.20/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*0.20)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 0;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleMidglacial_Mix_ReduceMLDSummerOnly10_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleGlacial_Mix
    elseif isequal(activesimulation,'NoNCycleGlacial_Mix')
EkmanFactor = 0.05/2; BoundaryFactor = 0.05/2; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleGlacial_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleGlacial_Ek
    elseif isequal(activesimulation,'NoNCycleGlacial_Ek')
EkmanFactor = 0.05; BoundaryFactor = 0; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleGlacial_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleGlacial_BM
    elseif isequal(activesimulation,'NoNCycleGlacial_BM')
EkmanFactor = 0; BoundaryFactor = 0.05;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleGlacial_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleGlacial_Mix_ReduceMLDTogether50
    elseif isequal(activesimulation,'NoNCycleGlacial_Mix_ReduceMLDTogether50')
MLDmin = 50; MLDstart = 50;
EkmanFactor = 0.05/2; BoundaryFactor = 0.05/2; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*0.05)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleGlacial_Mix_ReduceMLDTogether50_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleGlacial_Mix_ReduceMLDTogether25
    elseif isequal(activesimulation,'NoNCycleGlacial_Mix_ReduceMLDTogether25')
MLDmin = 25; MLDstart = 50;
EkmanFactor = 0.05/2; BoundaryFactor = 0.05/2; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*0.05)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleGlacial_Mix_ReduceMLDTogether25_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleGlacial_Mix_ReduceMLDTogether10
    elseif isequal(activesimulation,'NoNCycleGlacial_Mix_ReduceMLDTogether10')
MLDmin = 10; MLDstart = 50;
EkmanFactor = 0.05/2; BoundaryFactor = 0.05/2; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*0.05)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleGlacial_Mix_ReduceMLDTogether10_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleGlacial_Mix_ReduceMLDSummerOnly50
    elseif isequal(activesimulation,'NoNCycleGlacial_Mix_ReduceMLDSummerOnly50')
MLDmin = 50; MLDstart = 50;
EkmanFactor = 0.05/2; BoundaryFactor = 0.05/2; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*0.05)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 0;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleGlacial_Mix_ReduceMLDSummerOnly50_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleGlacial_Mix_ReduceMLDSummerOnly25
    elseif isequal(activesimulation,'NoNCycleGlacial_Mix_ReduceMLDSummerOnly25')
MLDmin = 25; MLDstart = 50;
EkmanFactor = 0.05/2; BoundaryFactor = 0.05/2; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*0.05)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 0;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleGlacial_Mix_ReduceMLDSummerOnly25_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% NoNCycleGlacial_Mix_ReduceMLDSummerOnly10
    elseif isequal(activesimulation,'NoNCycleGlacial_Mix_ReduceMLDSummerOnly10')
MLDmin = 10; MLDstart = 50;
EkmanFactor = 0.05/2; BoundaryFactor = 0.05/2; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*0.05)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 0;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {[['NoNCycleGlacial_Mix_ReduceMLDSummerOnly10_PI' InputTitleNumber '_' num2str(Ek0*EkmanFactor) 'Ek' num2str(BM0*BoundaryFactor) 'BM']]};


% FineGlacial_Ek
    elseif isequal(activesimulation,'FineGlacial_Ek')
EkmanFactor = fineset; BoundaryFactor = 0; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {['FineGlacial_PI' InputTitleNumber '_Ek']};


% FineGlacial_BM
    elseif isequal(activesimulation,'FineGlacial_BM')
EkmanFactor = 0; BoundaryFactor = fineset; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {['FineGlacial_PI' InputTitleNumber '_BM']};


% FineGlacial_Mix
    elseif isequal(activesimulation,'FineGlacial_Mix')
EkmanFactor = fineset/2; BoundaryFactor = fineset/2; 
FullyIterate = 0;
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {['FineGlacial_PI' InputTitleNumber '_Mix']};


% FineNoNCycle_Ek
    elseif isequal(activesimulation,'FineNoNCycle_Ek')
EkmanFactor = fineset; BoundaryFactor = 0; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0;
InputTitleNumber = StandardInputTitleNumber;
SaveName = {['FineNoNCycle_PI' InputTitleNumber '_Ek']};


% FineNoNCycle_BM
    elseif isequal(activesimulation,'FineNoNCycle_BM')
EkmanFactor = 0; BoundaryFactor = fineset; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {['FineNoNCycle_PI' InputTitleNumber '_BM']};


% FineNoNCycle_Mix
    elseif isequal(activesimulation,'FineNoNCycle_Mix')
EkmanFactor = fineset/2; BoundaryFactor = fineset/2; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {['FineNoNCycle_PI' InputTitleNumber '_Mix']};


% FineGlacial_Mix_remineralization
    elseif isequal(activesimulation,'FineGlacial_Mix_remineralization')
EkmanFactor = fineset/2; BoundaryFactor = fineset/2; 
FullyIterate = 0;
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = RemineralizationInputTitleNumber;
SaveName = {['FineGlacial_PI' InputTitleNumber '_Mix']};


% FineNoNCycle_Mix_remineralization
    elseif isequal(activesimulation,'FineNoNCycle_Mix_remineralization')
EkmanFactor = fineset/2; BoundaryFactor = fineset/2; 
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = RemineralizationInputTitleNumber;
SaveName = {['FineNoNCycle_PI' InputTitleNumber '_Mix']};


% FineNCycleReduceCDWConc_Mix_33p5
    elseif isequal(activesimulation,'FineNCycleReduceCDWConc_Mix_33p5')
EkmanFactor = fineset/2; BoundaryFactor = fineset/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 33.5/33.5;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {['FineNCycleReduceCDWConc_33p5_PI' InputTitleNumber '_Mix']};


% FineNoNCycleReduceCDWConc_Mix_33p5
    elseif isequal(activesimulation,'FineNoNCycleReduceCDWConc_Mix_33p5')
EkmanFactor = fineset/2; BoundaryFactor = fineset/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 33.5/33.5;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {['FineNoNCycleReduceCDWConc_33p5_PI' InputTitleNumber '_Mix']};


% FineNCycleReduceCDWConc_Mix_27
    elseif isequal(activesimulation,'FineNCycleReduceCDWConc_Mix_27')
EkmanFactor = fineset/2; BoundaryFactor = fineset/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 27/33.5;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {['FineNCycleReduceCDWConc_27_PI' InputTitleNumber '_Mix']};


% FineNoNCycleReduceCDWConc_Mix_27
    elseif isequal(activesimulation,'FineNoNCycleReduceCDWConc_Mix_27')
EkmanFactor = fineset/2; BoundaryFactor = fineset/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 27/33.5;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {['FineNoNCycleReduceCDWConc_27_PI' InputTitleNumber '_Mix']};


% FineNCycleReduceCDWConc_Mix_20
    elseif isequal(activesimulation,'FineNCycleReduceCDWConc_Mix_20')
EkmanFactor = fineset/2; BoundaryFactor = fineset/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 20/33.5;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {['FineNCycleReduceCDWConc_20_PI' InputTitleNumber '_Mix']};


% FineNoNCycleReduceCDWConc_Mix_20
    elseif isequal(activesimulation,'FineNoNCycleReduceCDWConc_Mix_20')
EkmanFactor = fineset/2; BoundaryFactor = fineset/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 20/33.5;
MLDFactor = 1;
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {['FineNoNCycleReduceCDWConc_20_PI' InputTitleNumber '_Mix']};


% FineNCycleReduceMLDTogether_50_Mix
     elseif isequal(activesimulation,'FineNCycleReduceMLDTogether_50_Mix')
MLDmin = 50; MLDstart = 50;
EkmanFactor = fineset/2; BoundaryFactor = fineset/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*fineset)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {['FineNCycleReduceMLDTogether_50_PI' InputTitleNumber '_Mix']};


% FineNoNCycleReduceMLDTogether_50_Mix
    elseif isequal(activesimulation,'FineNoNCycleReduceMLDTogether_50_Mix')
MLDmin = 50; MLDstart = 50;
EkmanFactor = fineset/2; BoundaryFactor = fineset/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*fineset)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {['FineNoNCycleReduceMLDTogether_50_PI' InputTitleNumber '_Mix']};


% FineNCycleReduceMLDTogether_25_Mix
     elseif isequal(activesimulation,'FineNCycleReduceMLDTogether_25_Mix')
MLDmin = 25; MLDstart = 50;
EkmanFactor = fineset/2; BoundaryFactor = fineset/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*fineset)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {['FineNCycleReduceMLDTogether_25_PI' InputTitleNumber '_Mix']};


% FineNoNCycleReduceMLDTogether_25_Mix
    elseif isequal(activesimulation,'FineNoNCycleReduceMLDTogether_25_Mix')
MLDmin = 25; MLDstart = 50;
EkmanFactor = fineset/2; BoundaryFactor = fineset/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*fineset)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {['FineNoNCycleReduceMLDTogether_25_PI' InputTitleNumber '_Mix']};


% FineNCycleReduceMLDTogether_10_Mix
     elseif isequal(activesimulation,'FineNCycleReduceMLDTogether_10_Mix')
MLDmin = 10; MLDstart = 50;
EkmanFactor = fineset/2; BoundaryFactor = fineset/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*fineset)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 1;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {['FineNCycleReduceMLDTogether_10_PI' InputTitleNumber '_Mix']};


% FineNoNCycleReduceMLDTogether_10_Mix
    elseif isequal(activesimulation,'FineNoNCycleReduceMLDTogether_10_Mix')
MLDmin = 10; MLDstart = 50;
EkmanFactor = fineset/2; BoundaryFactor = fineset/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*fineset)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 1;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {['FineNoNCycleReduceMLDTogether_10_PI' InputTitleNumber '_Mix']};

% FineNCycleReduceMLDSummerOnly_50_Mix
     elseif isequal(activesimulation,'FineNCycleReduceMLDSummerOnly_50_Mix')
MLDmin = 50; MLDstart = 50;
EkmanFactor = fineset/2; BoundaryFactor = fineset/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*fineset)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 0;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {['FineNCycleReduceMLDSummerOnly_50_PI' InputTitleNumber '_Mix']};


% FineNoNCycleReduceMLDSummerOnly_50_Mix
    elseif isequal(activesimulation,'FineNoNCycleReduceMLDSummerOnly_50_Mix')
MLDmin = 50; MLDstart = 50;
EkmanFactor = fineset/2; BoundaryFactor = fineset/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*fineset)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 0;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {['FineNoNCycleReduceMLDSummerOnly_50_PI' InputTitleNumber '_Mix']};


% FineNCycleReduceMLDSummerOnly_25_Mix
     elseif isequal(activesimulation,'FineNCycleReduceMLDSummerOnly_25_Mix')
MLDmin = 25; MLDstart = 50;
EkmanFactor = fineset/2; BoundaryFactor = fineset/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*fineset)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 0;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {['FineNCycleReduceMLDSummerOnly_25_PI' InputTitleNumber '_Mix']};


% FineNoNCycleReduceMLDSummerOnly_25_Mix
    elseif isequal(activesimulation,'FineNoNCycleReduceMLDSummerOnly_25_Mix')
MLDmin = 25; MLDstart = 50;
EkmanFactor = fineset/2; BoundaryFactor = fineset/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*fineset)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 0;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {['FineNoNCycleReduceMLDSummerOnly_25_PI' InputTitleNumber '_Mix']};


% FineNCycleReduceMLDSummerOnly_10_Mix
     elseif isequal(activesimulation,'FineNCycleReduceMLDSummerOnly_10_Mix')
MLDmin = 10; MLDstart = 50;
EkmanFactor = fineset/2; BoundaryFactor = fineset/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*fineset)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 0;
RunNCycle = 1; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {['FineNCycleReduceMLDSummerOnly_10_PI' InputTitleNumber '_Mix']};


% FineNoNCycleReduceMLDSummerOnly_10_Mix
    elseif isequal(activesimulation,'FineNoNCycleReduceMLDSummerOnly_10_Mix')
MLDmin = 10; MLDstart = 50;
EkmanFactor = fineset/2; BoundaryFactor = fineset/2;
FullyIterate = 0; 
KwFactor = 1;
CDWFactor = 1;
MLDFactor = (MLDmin+(MLDstart-MLDmin)*fineset)/MLDstart; % Interpolate the coarse set between the boundaries
ReduceSummerAndWinterMLD = 0;
RunNCycle = 0; 
InputTitleNumber = StandardInputTitleNumber;
SaveName = {['FineNoNCycleReduceMLDSummerOnly_10_PI' InputTitleNumber '_Mix']};

else
  disp('NO SIMULATION MATCH FOUND, TRY AGAIN');
EkmanFactor = NaN; BoundaryFactor = NaN;
RunNCycle = NaN; 
CDWFactor = NaN;
MLDFactor = NaN;
InputTitleNumber = NaN;
SaveName = {'NaN_File_BadIterationName'};
    end

SaveName = SaveName{1}; % Turn the cell name into a string
SaveName(SaveName=='.')='p'; % Replace the dots with 'p's
SaveName = {SaveName}; % Turn it back into a string    
    
    