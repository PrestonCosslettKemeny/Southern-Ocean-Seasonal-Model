function MI = SOM_GenerateInputs(Input0)

% This function evaluates "Input0". The function is necessary
% because parallel processing requires functional definitions 
% to avoid errors.

eval(Input0);

end