function [N0] = SOM_InitialConditions

% This function defines the initial conditions of the model. 

% Initial NO3 14N and 15N
Rair = 0.0036765;  
R = Rair*(4.74/1000+1);
SrfWaterInitialNO3_N14  = 5/(1+R);                    
SrfWaterInitialNO3_N15  = 5-SrfWaterInitialNO3_N14;   
TminWaterInitialNO3_N14  = 10/(1+R);                  
TminWaterInitialNO3_N15  = 10-TminWaterInitialNO3_N14;

% Initial biomass 14N and 15N
R = Rair*(0/1000+1);
BiomassConc = 1e-5;
Bio_N14  = BiomassConc/(1+R);                         
Bio_N15  = BiomassConc-Bio_N14;                       

N0 = [SrfWaterInitialNO3_N14;  % 1: Surface NO3 N14
      SrfWaterInitialNO3_N15;  % 2: Surface NO3 N15
      TminWaterInitialNO3_N14; % 3: Tmin NO3 N14
      TminWaterInitialNO3_N15; % 4: Tmin NO3 N15
      Bio_N14;                 % 5: Surface NH4 N14
      Bio_N15;                 % 6: Surface NH4 N15
      Bio_N14;                 % 7: Diatom N14
      Bio_N15;                 % 8: Diatom N15
      Bio_N14;                 % 9: Zooplankton N14
      Bio_N15;                 % 10: Zooplankton N15
      Bio_N14;                 % 11: Non-diatom N14
      Bio_N15;                 % 12: Non-diatom N15
      0.00000;                 % 13: Diatom export production N14
      0.00000;                 % 14: Diatom export production N15 
      0.00000;                 % 15: Zooplankton export production N14
      0.00000;                 % 16: Zooplankton export production N15 
      Bio_N14;                 % 17: Tmin NH4 N14
      Bio_N15;                 % 18: Tmin NH4 N15 
      0000000;                 % 19: Gross AZ 14N inputs
      0000000;                 % 20: Gross AZ 15N inputs
      0000000;                 % 21: Gross AZ 14N outputs
      0000000;                 % 22: Gross AZ 15N outputs 
      0000000;                 % 23: Exported frustule-bound 14N
      0000000;                 % 24: Exported frustule-bound 15N
      0000000;                 % 25: Model frustule-bound 14N
      0000000];                % 26: Model frustule-bound 15N 
end

