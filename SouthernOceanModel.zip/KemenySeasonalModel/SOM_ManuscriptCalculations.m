%% IN-TEXT
SOM_ParameterInput1

MI.DtmVmax*1000;            % 57 umol/m3/d
MI.DtmKnNO3*1000;           % 500 umol/m3
MI.DtmSink*100;             % 3.0 %/day
MI.DtmFrustFrac*100;        % 0.1 %
MI.ZooConsumptionDtm*100;   % 3.0 %/day
MI.ZooConsumptionNDm*100;   % 17 %/day
MI.ZooDigestiveFraction;    % 95%/day
MI.ZooDigestiveEpsilon;     % -3 per mil
MI.ZooNH4Production;        % 50%/day
MI.ZooNH4ProductionEpsilon; % -3 per mil 
MI.NDmNH4ConsumptionSummer; % 40%/day
MI.NDmUptakeEpsilon;        % 0 per mil
MI.NDmToNH4*100;            % 3%
MI.NH4NitrificationEpsilon; % -15 per mil
MI.BiomassRemineralizationEpsilon; %0 per mil

MI.endsummersurfconc; % 25.4 mmol/m3 
MI.endsummersurfd15N; % 6.0 per mil  
MI.endsummerTminconc; % 30 mmol/m3
MI.endsummerTmind15N; % 5.05 per mil
MI.CDWConc; % 33.5 mmol/m3 
MI.CDWd15N; % 4.74 per mil 

load('StandardInterglacial_PI1_10Ek10BM_ODE15s_HighRes_150yr','endssn','steady'); NCycle = endssn;   NCycleSteady = steady;
steadydays = 365*(NCycleSteady.day/365-(MI.ModelLength-1));
steadysummerdays = steadydays<MI.SummerSeason;
round(max(NCycleSteady.Dtm.Srf.Conc(steadysummerdays)),2); % 0.93 Maximum Dtm concentration in summer
round(max(NCycleSteady.Zoo.Srf.Conc(steadysummerdays)),2); % 0.34 Maximum Zooplankton concentration in summer
round(max(NCycleSteady.NDm.Srf.Conc(steadysummerdays)),2); % 0.97 Maximum non-diatom phytoplankton concentration in summer
round(max(NCycleSteady.NH4.Srf.Conc(steadysummerdays)),2); % 0.49 Maximum NH4 concentration in summer

% Difference in Tmin d15N as a result of N cycling
load('StandardInterglacial_PI1_10Ek10BM_ODE15s_HighRes_150yr','endssn','steady'); NCycle = endssn;   NCycleSteady = steady;
load('NoNCycleInterglacial_PI1_10Ek10BM_ODE15s_HighRes_150yr','endssn','steady'); NoNCycle = endssn; NoNCycleSteady = steady;
round(NoNCycle.summer.NO3.Tmn.d15N-NCycle.summer.NO3.Tmn.d15N,2); % 0.42

% How much reduction in supply is required? 
load('FineGlacial_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector');  FirstIndxAfterCrossing = max(find((results.winter.exp.Fru.d15N>5))); 100-SupplyVector([FirstIndxAfterCrossing FirstIndxAfterCrossing+1])/20*100; % 82.5       82.0
load('FineGlacial_PI1_Ek_ODE15s_HighRes_150yr','results','SupplyVector');   FirstIndxAfterCrossing = max(find((results.winter.exp.Fru.d15N>5))); 100-SupplyVector([FirstIndxAfterCrossing FirstIndxAfterCrossing+1])/20*100; % 83.5       83.0
load('FineGlacial_PI1_BM_ODE15s_HighRes_150yr','results','SupplyVector');   FirstIndxAfterCrossing = max(find((results.winter.exp.Fru.d15N>5))); 100-SupplyVector([FirstIndxAfterCrossing FirstIndxAfterCrossing+1])/20*100; % 81.0       80.5
load('FineNoNCycle_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector'); FirstIndxAfterCrossing = max(find((results.winter.exp.Fru.d15N>5))); 100-SupplyVector([FirstIndxAfterCrossing FirstIndxAfterCrossing+1])/20*100; % 63.0       62.5
load('FineNoNCycle_PI1_Ek_ODE15s_HighRes_150yr','results','SupplyVector');  FirstIndxAfterCrossing = max(find((results.winter.exp.Fru.d15N>5))); 100-SupplyVector([FirstIndxAfterCrossing FirstIndxAfterCrossing+1])/20*100; % 66.0       65.5
load('FineNoNCycle_PI1_BM_ODE15s_HighRes_150yr','results','SupplyVector');  FirstIndxAfterCrossing = max(find((results.winter.exp.Fru.d15N>5))); 100-SupplyVector([FirstIndxAfterCrossing FirstIndxAfterCrossing+1])/20*100; % 60.0       59.5
    
% How much reduction in supply is required? 
load('FineNCycleReduceMLDSummerOnly_50_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector');  FirstIndxAfterCrossing = max(find((results.winter.exp.Fru.d15N>5))); 100-SupplyVector([FirstIndxAfterCrossing FirstIndxAfterCrossing+1])/20*100;   % 82.5   82
load('FineNCycleReduceMLDSummerOnly_25_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector');   FirstIndxAfterCrossing = max(find((results.winter.exp.Fru.d15N>5))); 100-SupplyVector([FirstIndxAfterCrossing FirstIndxAfterCrossing+1])/20*100;  % 90.5   90
load('FineNCycleReduceMLDSummerOnly_10_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector');   FirstIndxAfterCrossing = max(find((results.winter.exp.Fru.d15N>5))); 100-SupplyVector([FirstIndxAfterCrossing FirstIndxAfterCrossing+1])/20*100;  % 96     95.5
load('FineNoNCycleReduceMLDSummerOnly_50_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector'); FirstIndxAfterCrossing = max(find((results.winter.exp.Fru.d15N>5))); 100-SupplyVector([FirstIndxAfterCrossing FirstIndxAfterCrossing+1])/20*100;  % 63     62.5
load('FineNoNCycleReduceMLDSummerOnly_25_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector');  FirstIndxAfterCrossing = max(find((results.winter.exp.Fru.d15N>5))); 100-SupplyVector([FirstIndxAfterCrossing FirstIndxAfterCrossing+1])/20*100; % 77.5   77
load('FineNoNCycleReduceMLDSummerOnly_10_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector');  FirstIndxAfterCrossing = max(find((results.winter.exp.Fru.d15N>5))); 100-SupplyVector([FirstIndxAfterCrossing FirstIndxAfterCrossing+1])/20*100; % 90     89.5
    % How much reduction in supply is required? 
    load('FineNCycleReduceMLDTogether_50_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector');  FirstIndxAfterCrossing = max(find((results.winter.exp.Fru.d15N>5))); 100-SupplyVector([FirstIndxAfterCrossing FirstIndxAfterCrossing+1])/20*100;   % 82.5     82
    load('FineNCycleReduceMLDTogether_25_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector');   FirstIndxAfterCrossing = max(find((results.winter.exp.Fru.d15N>5))); 100-SupplyVector([FirstIndxAfterCrossing FirstIndxAfterCrossing+1])/20*100;  % 90.5     90
    load('FineNCycleReduceMLDTogether_10_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector');   FirstIndxAfterCrossing = max(find((results.winter.exp.Fru.d15N>5))); 100-SupplyVector([FirstIndxAfterCrossing FirstIndxAfterCrossing+1])/20*100;  % 96        95.5
    load('FineNoNCycleReduceMLDTogether_50_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector'); FirstIndxAfterCrossing = max(find((results.winter.exp.Fru.d15N>5))); 100-SupplyVector([FirstIndxAfterCrossing FirstIndxAfterCrossing+1])/20*100;  % 63        62.5
    load('FineNoNCycleReduceMLDTogether_25_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector');  FirstIndxAfterCrossing = max(find((results.winter.exp.Fru.d15N>5))); 100-SupplyVector([FirstIndxAfterCrossing FirstIndxAfterCrossing+1])/20*100; % 77.5      77
    load('FineNoNCycleReduceMLDTogether_10_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector');  FirstIndxAfterCrossing = max(find((results.winter.exp.Fru.d15N>5))); 100-SupplyVector([FirstIndxAfterCrossing FirstIndxAfterCrossing+1])/20*100; % 89.5      89

% How much reduction in supply is required? 
load('FineNCycleReduceCDWConc_33p5_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector','CDWFactor');   FirstIndxAfterCrossing = max(find((results.winter.exp.Fru.d15N>5))); 100-SupplyVector([FirstIndxAfterCrossing FirstIndxAfterCrossing+1])/20*100; % 82.5     82
load('FineNCycleReduceCDWConc_27_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector','CDWFactor');     FirstIndxAfterCrossing = max(find((results.winter.exp.Fru.d15N>5))); 100-SupplyVector([FirstIndxAfterCrossing FirstIndxAfterCrossing+1])/20*100; % 77.5     77
load('FineNCycleReduceCDWConc_20_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector','CDWFactor');     FirstIndxAfterCrossing = max(find((results.winter.exp.Fru.d15N>5))); 100-SupplyVector([FirstIndxAfterCrossing FirstIndxAfterCrossing+1])/20*100; % 68       67.5
load('FineNoNCycleReduceCDWConc_33p5_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector','CDWFactor'); FirstIndxAfterCrossing = max(find((results.winter.exp.Fru.d15N>5))); 100-SupplyVector([FirstIndxAfterCrossing FirstIndxAfterCrossing+1])/20*100; % 63       62.5
load('FineNoNCycleReduceCDWConc_27_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector','CDWFactor');   FirstIndxAfterCrossing = max(find((results.winter.exp.Fru.d15N>5))); 100-SupplyVector([FirstIndxAfterCrossing FirstIndxAfterCrossing+1])/20*100; % 53.5     53
load('FineNoNCycleReduceCDWConc_20_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector','CDWFactor');   FirstIndxAfterCrossing = max(find((results.winter.exp.Fru.d15N>5))); 100-SupplyVector([FirstIndxAfterCrossing FirstIndxAfterCrossing+1])/20*100; % 34.5     34

% Second estimate on reduced supply
load('FineGlacial_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector'); SaveCon = '';   NCycle = results;     
modelNCycleexport = NCycle.winter.exp.Tot.Conc;
modelNCycleexport = modelNCycleexport./modelNCycleexport(end)*100;
indx = max(find(modelNCycleexport<50));
100-SupplyVector([indx indx+1])/20*100; % 93   92.5

load('FineNCycleReduceMLDSummerOnly_25_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector'); SaveCon = '';   NCycle = results;     
modelNCycleexport = NCycle.winter.exp.Tot.Conc;
modelNCycleexport = modelNCycleexport./modelNCycleexport(end)*100;
indx = max(find(modelNCycleexport<50));
100-SupplyVector([indx indx+1])/20*100; % 91.5   91
    load('FineNCycleReduceMLDTogether_25_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector'); SaveCon = '';   NCycle = results;     
    modelNCycleexport = NCycle.winter.exp.Tot.Conc;
    modelNCycleexport = modelNCycleexport./modelNCycleexport(end)*100;
    indx = max(find(modelNCycleexport<50));
    100-SupplyVector([indx indx+1])/20*100; % 91.5  91

% Reduction in supply to reach NO3- exhaustion 
load('FineGlacial_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector','RUNSTAT','MBV'); SaveCon = '';   
NCycle = results;      
SupplyIndx = SupplyVector>=0.2;    
summerNcycle = NCycle.summer.NO3.Srf.Conc(SupplyIndx);
xNCycle = SupplyVector(SupplyIndx);
index = max(find(summerNcycle<.1));
val1 = xNCycle(index); % 1.9

load('FineNoNCycle_PI1_Mix_ODE15s_HighRes_150yr','results','SupplyVector','RUNSTAT','MBV'); SaveCon = '';
NCycle = results;      
SupplyIndx = SupplyVector>=0.2;    
summerNcycle = NCycle.summer.NO3.Srf.Conc(SupplyIndx);
xNCycle = SupplyVector(SupplyIndx);
index = max(find(summerNcycle<.1));
val2 = xNCycle(index); % 2.5


%% Table 1
SOM_ParameterInput1

MI.ModelLength;                      % 150 % [years]    - Length of the simulation
MI.SummerSeason;                     % 182 % [Day]      - Length of the summer season
MI.WinterSeason;                     % 183 % [Day]      - Length of the winter season
MI.DtmGrowDayEnd-MI.DtmGrowDayStart; % 90 [Day]         - Length of diatom season
MI.ANZArea;                          % 1.8e+13 [m2]     - Area of the AZ
MI.MLDSummer;                        % 50 % [meters]    - Depth of ANZ summer mixed layer
MI.MLDWinter-MI.MLDSummer;           % 125 m % [meters] - Depth of ANZ Tmin layer

% Daily upwelling of water
TotalUpwelling = MI.EkmanCDWTransport/2; % 8.64e+11
DailyUpwelling = (TotalUpwelling/(MI.ANZArea))*100; % 4.8 cm/day
% [10 Sv] / [(Sv*days)/(m^3)] / [m^2] * [cm/m]

% CDW values
MI.CDWConc; % 33.5 mmol/m^3
MI.CDWd15N; % 4.74 per mil

% Diatom parameters
MI.DtmVmax*1000;  % 57 umol/m3/d
MI.DtmKnNO3*1000; % 500 umol/m3
MI.DtmNO3UptakeEpsilon; % -5.85 per mil
MI.DtmSink*100;   % 3.0 %/day

% Zooplankton parameters
MI.ZooConsumptionDtm*100;   % 3.0 %/day
MI.ZooConsumptionEpsilon;   % 0 per mil
MI.ZooConsumptionNDm*100;   % 17 %/day
MI.ZooDigestiveFraction;    % 95%/day
MI.ZooDigestiveEpsilon;     % -3 per mil
MI.ZooNH4Production;        % 50%/day
MI.ZooNH4ProductionEpsilon; % -3 per mil 

% Non-diatom cyanobacteria
MI.NDmNH4ConsumptionSummer*100; % 40%/day
MI.NDmUptakeEpsilon;        % 0 per mil
MI.NDmToNH4*100;            % 3%

% NH4
MI.NH4SrfRenitrificationSummer; % 0%/day
MI.NH4SrfRenitrificationWinter; % 5%/day
MI.NH4TmnRenitrification; % 5%/day
MI.NH4NitrificationEpsilon; % -15 per mil

%% Table 2
SOM_ParameterInput1

% DECLARE THE SEASONAL TARGETS
MI.endsummersurfconc; % 25.4 mmol/m3 % End-summer surface NO3 target
MI.endsummersurfd15N; % 6.0 per mil  % End-summer surface d15N target
MI.endsummerTminconc; % 30 mmol/m3
MI.endsummerTmind15N; % 5.05 per mil

load('StandardInterglacial_PI1_10Ek10BM_ODE15s_HighRes_150yr','endssn','steady'); NCycle = endssn;   NCycleSteady = steady;

round(endssn.summer.NO3.Srf.Conc,2); % 25.25 % Surface [NO3] at end-summer
round(endssn.summer.NO3.Srf.d15N,2); % 6.03  % Surface d15N at end-summer
round(endssn.summer.NO3.Tmn.Conc,2); % 30.32 % Tmin [NO3] at end-summer
round(endssn.summer.NO3.Tmn.d15N,2); % 5.02  % Tmin d15N at end-summer

steadydays = 365*(NCycleSteady.day/365-(MI.ModelLength-1));
steadysummerdays = steadydays<MI.SummerSeason;
round(max(NCycleSteady.Dtm.Srf.Conc(steadysummerdays)),2); % 0.93 Maximum Dtm concentration in summer
round(max(NCycleSteady.Zoo.Srf.Conc(steadysummerdays)),2); % 0.34 Maximum Zooplankton concentration in summer
round(max(NCycleSteady.NDm.Srf.Conc(steadysummerdays)),2); % 0.97 Maximum non-diatom phytoplankton concentration in summer
round(max(NCycleSteady.NH4.Srf.Conc(steadysummerdays)),2); % 0.49 Maximum NH4 concentration in summer
round(max(NCycleSteady.NH4.Srf.Conc(~steadysummerdays)),2); % 0.72 Maximum NH4 concentration in winter

round(endssn.summer.PaN.Srf.Conc,2); % 1.00  % PN concentration 
round(endssn.summer.PaN.Srf.d15N,2); % -5.08 % PN-d15N at end of summer

round(endssn.winter.exp.Tot.Conc,1); % 165.3 % End-winter export production
round(endssn.winter.exp.Dtm.Conc/endssn.winter.exp.Zoo.Conc,2); % 2.21 % Dtm/zoo export ratio


%% TABLE S2
SOM_ParameterInput2
load('StandardInterglacial_PI2_10Ek10BM_ODE15s_HighRes_150yr','endssn','steady'); NCycle = endssn;   NCycleSteady = steady;

round(endssn.summer.NO3.Srf.Conc,2); % 25.06 % Surface [NO3] at end-summer
round(endssn.summer.NO3.Srf.d15N,2); % 6.11  % Surface d15N at end-summer
round(endssn.summer.NO3.Tmn.Conc,2); % 30.31 % Tmin [NO3] at end-summer
round(endssn.summer.NO3.Tmn.d15N,2); % 5.03  % Tmin d15N at end-summer

steadydays = 365*(NCycleSteady.day/365-(MI.ModelLength-1));
steadysummerdays = steadydays<MI.SummerSeason;
round(max(NCycleSteady.Dtm.Srf.Conc(steadysummerdays)),2); % 1.36 Maximum Dtm concentration in summer
round(max(NCycleSteady.Zoo.Srf.Conc(steadysummerdays)),2); % 0.16 Maximum Zooplankton concentration in summer
round(max(NCycleSteady.NDm.Srf.Conc(steadysummerdays)),2); % 0.47 Maximum non-diatom phytoplankton concentration in summer
round(max(NCycleSteady.NH4.Srf.Conc(steadysummerdays)),2); % 0.23 Maximum NH4 concentration in summer
round(max(NCycleSteady.NH4.Srf.Conc(~steadysummerdays)),2); % 0.37 Maximum NH4 concentration in winter

round(endssn.summer.PaN.Srf.Conc,2); % 0.55  % PN concentration 
round(endssn.summer.PaN.Srf.d15N,2); % -4.31 % PN-d15N at end of summer

round(endssn.winter.exp.Tot.Conc,1); % 173.5 % End-winter export production
round(endssn.winter.exp.Dtm.Conc/endssn.winter.exp.Zoo.Conc,2); % 6.95 % Dtm/zoo export ratio
