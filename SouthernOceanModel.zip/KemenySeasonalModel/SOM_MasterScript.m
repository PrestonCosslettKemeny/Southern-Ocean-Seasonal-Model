%% Southern Ocean Seasonal Model

% This is the primary script for running the Southern Ocean
% seasonal model. This script defines a range of parameter 
% values, runs the model, and saves the output. Figures are 
% generated in ModelManuscriptFigures.

% Primary author: Preston Cosslett Kemeny
%    pkemeny@caltech.edu, preston.kemeny@gmail.com
% Additional authors: Emma Kast, Mathis Hain
% Senior author: Daniel Sigman

%% 1. CLEAR THE WORKSPACE
clearvars; 

%% 2. SELECT WHICH SIMULATIONS TO RUN
% The variable 'IterationList' contains the names of simulations
% to be run in series. Each simulation entails run one or multiple 
% runs of the model to steady-state conditions, with parameters
% specific to each simulation.

IterationList = {'StandardInterglacial_Mix'};

% Recommended to run on a SINGLE PROCESSOR:
%IterationList = {'StandardInterglacial_Mix',...
%                 'StandardMidglacial_Mix',...
%                 'StandardGlacial_Mix',...
%                 'StandardInterglacial_Mix_Remineralization',...
%                 'StandardInterglacial_Ek',...
%                 'StandardMidglacial_Ek',...
%                 'StandardGlacial_Ek',...
%                 'StandardInterglacial_BM',...
%                 'StandardMidglacial_BM',...
%                 'StandardGlacial_BM',...
%                 'NoNCycleInterglacial_Mix',...
%                 'NoNCycleMidglacial_Mix',...
%                 'NoNCycleGlacial_Mix',...
%                 'NoNCycleInterglacial_Ek',...
%                 'NoNCycleMidglacial_Ek',...
%                 'NoNCycleGlacial_Ek',...
%                 'NoNCycleInterglacial_BM',...
%                 'NoNCycleMidglacial_BM',...
%                 'NoNCycleGlacial_BM',...
%                 'StandardInterglacial_Mix_ReduceMLDSummerOnly50',...
%                 'StandardInterglacial_Mix_ReduceMLDSummerOnly25',...
%                 'StandardInterglacial_Mix_ReduceMLDSummerOnly10',...
%                 'StandardMidglacial_Mix_ReduceMLDSummerOnly50',...
%                 'StandardMidglacial_Mix_ReduceMLDSummerOnly25',...
%                 'StandardMidglacial_Mix_ReduceMLDSummerOnly10',...
%                 'StandardGlacial_Mix_ReduceMLDSummerOnly50',...
%                 'StandardGlacial_Mix_ReduceMLDSummerOnly25',...
%                 'StandardGlacial_Mix_ReduceMLDSummerOnly10',...
%                 'NoNCycleInterglacial_Mix_ReduceMLDSummerOnly50',...
%                 'NoNCycleInterglacial_Mix_ReduceMLDSummerOnly25',...
%                 'NoNCycleInterglacial_Mix_ReduceMLDSummerOnly10',...
%                 'NoNCycleMidglacial_Mix_ReduceMLDSummerOnly50',...
%                 'NoNCycleMidglacial_Mix_ReduceMLDSummerOnly25',...
%                 'NoNCycleMidglacial_Mix_ReduceMLDSummerOnly10',...
%                 'NoNCycleGlacial_Mix_ReduceMLDSummerOnly50',...
%                 'NoNCycleGlacial_Mix_ReduceMLDSummerOnly25',...
%                 'NoNCycleGlacial_Mix_ReduceMLDSummerOnly10',...
%                 'StandardInterglacial_Mix_ReduceMLDTogether50',...
%                 'StandardInterglacial_Mix_ReduceMLDTogether25',...
%                 'StandardInterglacial_Mix_ReduceMLDTogether10',...
%                 'StandardMidglacial_Mix_ReduceMLDTogether50',...
%                 'StandardMidglacial_Mix_ReduceMLDTogether25',...
%                 'StandardMidglacial_Mix_ReduceMLDTogether10',...
%                 'StandardGlacial_Mix_ReduceMLDTogether50',...
%                 'StandardGlacial_Mix_ReduceMLDTogether25',...
%                 'StandardGlacial_Mix_ReduceMLDTogether10',...
%                 'NoNCycleInterglacial_Mix_ReduceMLDTogether50',...
%                 'NoNCycleInterglacial_Mix_ReduceMLDTogether25',...
%                 'NoNCycleInterglacial_Mix_ReduceMLDTogether10',...
%                 'NoNCycleMidglacial_Mix_ReduceMLDTogether50',...
%                 'NoNCycleMidglacial_Mix_ReduceMLDTogether25',...
%                 'NoNCycleMidglacial_Mix_ReduceMLDTogether10',...
%                 'NoNCycleGlacial_Mix_ReduceMLDTogether50',...
%                 'NoNCycleGlacial_Mix_ReduceMLDTogether25',...
%                 'NoNCycleGlacial_Mix_ReduceMLDTogether10'};

% Recommended to run on on PARALLEL PROCESSING:
%IterationList = {'FineGlacial_Mix',...
                 %'FineNoNCycle_Mix',...
                 %'FineGlacial_Ek',...
                 %'FineNoNCycle_Ek',...
                 %'FineGlacial_BM',...
                 %'FineNoNCycle_BM',...
                 %'FineNCycleReduceCDWConc_Mix_33p5',...  
                 %'FineNCycleReduceCDWConc_Mix_27',...
                 %'FineNCycleReduceCDWConc_Mix_20',...
                 %'FineNoNCycleReduceCDWConc_Mix_33p5',...
                 %'FineNoNCycleReduceCDWConc_Mix_27',...
                 %'FineNoNCycleReduceCDWConc_Mix_20',...                
                 %'FineGlacial_Mix_remineralization',...
                 %'FineNoNCycle_Mix_remineralization',...
                 %'FineNCycleReduceMLDSummerOnly_50_Mix',...                               
                 %'FineNoNCycleReduceMLDSummerOnly_50_Mix',...
                 %'FineNCycleReduceMLDSummerOnly_25_Mix',...
                 %'FineNoNCycleReduceMLDSummerOnly_25_Mix'...  
                 %'FineNCycleReduceMLDSummerOnly_10_Mix',...
                 %'FineNoNCycleReduceMLDSummerOnly_10_Mix'...
                 %'FineNoNCycleReduceMLDTogether_50_Mix',...
                 %'FineNCycleReduceMLDTogether_50_Mix',...
                 %'FineNCycleReduceMLDTogether_25_Mix',...
                 %'FineNoNCycleReduceMLDTogether_25_Mix',...
                 %'FineNCycleReduceMLDTogether_10_Mix',...
                 %'FineNoNCycleReduceMLDTogether_10_Mix'};                 
                 
%IterationList = {'CoarseFullyIteratedNCycle',...
                 %'CoarseFullyIteratedNoNCycle'};     
             
%% 3. DEFINE MODEL PARAMETERS

% The number of the "ParameterInput" variable for the
% standard model run and for the model run with 
% fractionation during remineralization. 
StandardInputTitleNumber = '1'; 
RemineralizationInputTitleNumber = '2';

% Select if model should be run in normal 
% resolution (RelTol and AbsTol at defauly values)
% or in high resoltion (RelTol = 1e-6, AbsTol = 1e-12) 
% Note that model simulations in normal resolution run 
% much faster than those in high resolution, and generally
% the results are quite similar. All results in the 
% manuscript based on this research were found by running
% simulations in 'HighRes'. 
RunType = 'HighRes'; % 'HighRes','NormRes', 'AltRes'

% 'fineset' is a vectors of multipliers for scaling basic model
% input parameters (defined in ParameterInputX). This functionality 
% is principally used when running ice age simulations to 
% reduce the supply of NO3- through basal mixing or Ekman 
% upwelling, but can also be used to alter the concentration
% of CDW 14N/15N or the depth of the mixed layer. When setting
% this vector, select the values by which the basic parameter 
% should be multiplied. For example, a value of 0.5 in fineset 
% will tell the model to run with 50% of the chosen parameters. 
coarseset = [0.001 .0025 0.005 .01 0.0125 .015 .02 0.025 .03 .04 .05:.025:.25 .30 .35 .4 .45 .5 .6 .7 .8 .9 1]; % 29 runs
fineset =  [0.005:.005:1];
    
% Define Sverdrup scaling factor for converting flux units
Sv =  1/(24*60*60*1e6); %  [day/m^3]      

% Check that all simulation names are acceptable
for z=1:length(IterationList)
   activesimulation = IterationList{z};  % Get each simulation name in turn
   SOM_FindIterationVariables;           % Find the details of the simulation
if isnan(EkmanFactor)                    % Check whether the simulation is found    
    disp(sprintf('PROBLEM WITH ITERATION NAME: %s',activesimulation)); break; end; end
disp('Iteration names are acceptable');  % If found, proceed with the model run
disp(sprintf('Running in: %s',RunType)); % Display the resolution of the run


%% 4. FIND MODEL INPUTS FOR EACH ITERATION
for i=1:length(IterationList)            % Iterate over the list of simulations
    activesimulation = IterationList{i}  % Isolate this simulation name

% Display the active simulation
display(['Simulation ' num2str(i) '/' num2str(length(IterationList))])
    
% Find the details of the simulation
SOM_FindIterationVariables; 

% Input0 is the name of the file where model parameters are kept
% which are constant over the course of the similation. 
Input0 = ['SOM_ParameterInput' InputTitleNumber];

% Find simulation parameters based on the length of the vectors
% for this scenario (as defined in SOM_FindIterationParameters).
lenEF = length(EkmanFactor);    % Calculate the length of the Ekman vector
lenBF = length(BoundaryFactor); % Calculate the length of the basal mixing vector
lenCDW = length(CDWFactor);     % Calculate the length of the CDW reduction vector
lenKw = length(KwFactor);       % Calculate the length of the MM 1/2 saturation reduction vector
lenMLD = length(MLDFactor);     % Calculate the length of the MLD reduction vector
if lenEF>lenBF & lenBF==1 & lenCDW == 1 & lenKw == 1 & lenMLD == 1 % Reduce only upwelling
    EkIterList  = EkmanFactor;
    BMIterList  = BoundaryFactor*ones(1,lenEF);
    CDWIterList = CDWFactor*ones(1,lenEF);
    KwIterList  = KwFactor*ones(1,lenEF);
    MLDIterList = MLDFactor*ones(1,lenEF);
elseif lenBF>lenEF & lenEF ==1 & lenCDW == 1 & lenKw == 1 & lenMLD == 1 % Reduce only basal mixing
    EkIterList  = EkmanFactor*ones(1,lenBF);
    BMIterList  = BoundaryFactor;
    CDWIterList = CDWFactor*ones(1,lenBF);
    KwIterList  = KwFactor*ones(1,lenBF); 
    MLDIterList = MLDFactor*ones(1,lenBF);
elseif lenBF==lenEF & lenBF == lenCDW & lenCDW == lenKw & lenKw == lenMLD % Reduce everything equally
    EkIterList  = EkmanFactor;
    BMIterList  = BoundaryFactor;
    CDWIterList = CDWFactor;   
    KwIterList  = KwFactor;
    MLDIterList = MLDFactor;      
elseif lenBF==lenEF & lenCDW == 1 & lenKw == 1 & lenMLD == 1 % Reduce upwelling and basal mixing
    if FullyIterate == 0;
    EkIterList = EkmanFactor;
    BMIterList = BoundaryFactor;
    CDWIterList = CDWFactor*ones(1,lenBF);
    KwIterList  = KwFactor*ones(1,lenBF);
    MLDIterList = MLDFactor*ones(1,lenBF);
    elseif FullyIterate ==1; 
        Ekmanrepmat = repmat(EkmanFactor,lenEF,1);    % Make a matrix of repeating elements
        EkIterList = Ekmanrepmat(:);                  % Turn that matrix into a column [x x x ... x+1 x+1 x+1... x+2 x+2 x+2...] 
        BMIterList = repmat(BoundaryFactor',lenBF,1); % Make a column directly       [x x+1 x+2 ... x x+1 x+2... x x+1 x+2...]
        CDWIterList = CDWFactor*ones(lenBF*lenEF,1);  % Make a vector
        KwIterList  = KwFactor*ones(lenBF*lenEF,1);   % Make a vector
        MLDIterList = MLDFactor*ones(lenBF*lenEF,1);  % Make a vector
    end
elseif lenBF==lenEF & lenEF == lenMLD & lenCDW == 1 & lenKw == 1 % Reduce upwelling, basal mixing, and MLD
    EkIterList = EkmanFactor;
    BMIterList = BoundaryFactor;
    CDWIterList = CDWFactor*ones(1,lenBF);
    KwIterList  = KwFactor*ones(1,lenBF);
    MLDIterList = MLDFactor;
else display('BAD INPUTS!!!');
end

MBV = []; % Define the mass balance vector
% Calculate the total upwelling in each simulation
SupplyVector = 20*EkIterList+20*BMIterList; 
  
% Select either of the following two 'for' loops to run the model on 
% either a single processor or in parallel, and comment out the other
% two lines. For a singe model run, running on a single core is
% is generally faster. For running a simulation with multiple values, 
% running in parallel is much faster. A recommendation is to set up
% multiple scenarios, put the model in parallel, and then upload the
% code to be run on a multi-core server.

% FOR loop will run on a single core
display('RUNNING ON SINGLE PROCESSOR'); 
for itercounter = 1:length(BMIterList)     

% PARFOR loop will run in parallel processors
%display('RUNNING ON PARALLEL PROCESSING'); 
%parfor itercounter = 1:length(BMIterList)  

% MI stands for "MasterInput" and it contains all of the parameter
% values for the given run of the given simulation.
MI = struct();  MI = SOM_GenerateInputs(Input0);  % Load given input variables
    % Update the MI variables with the parameters for this scenario
    MI = SOM_UpdateInputParameters(MI,{'EkmanCDWTransport'},EkIterList,itercounter); % Update Ekman pumping
    MI = SOM_UpdateInputParameters(MI,{'MixTmnCDWBnd'},BMIterList,itercounter);      % Update Basal mixing
    MI = SOM_UpdateInputParameters(MI,{'CDWN14','CDWN15'},CDWIterList,itercounter);  % Update CDW 14N and 15N
    MI = SOM_UpdateInputParameters(MI,{'DtmKnNO3'},KwIterList,itercounter);          % Update parameters of diatom NO3 assimilation
    
    if ReduceSummerAndWinterMLD == 1    % Reduce the MLD of both summer and winter
        MI = SOM_UpdateInputParameters(MI,{'MLDSummer','MLDWinter'},MLDIterList,itercounter); % Update the depth of the mixed layer
    elseif ReduceSummerAndWinterMLD == 0  % Reduce the MLD of only summer
        MI = SOM_UpdateInputParameters(MI,{'MLDSummer'},MLDIterList,itercounter); % Update the depth of the mixed layer
    end   
    
% Display information about the current simulation    
display(['Iteration ' num2str(i) '/' num2str(length(IterationList)) ', Simulation ' num2str(itercounter) '/' num2str(length(BMIterList)) ', supply = ' num2str(SupplyVector(itercounter)) 'Sv, Summer MLD = ' num2str(MI.MLDSummer) 'm, Winter MLD = '  num2str(num2str(MI.MLDWinter)) 'm']) % Usefull for tracking that the model is still functioning
                        
    if RunNCycle~=1                         % To run without N cycling 
        MI.ZooConsumptionDtm = 0;           % Stop zooplankton growth
        MI.NDmNH4ConsumptionSummer = 0;     % Stop non-diatom phytoplankton growth
    end           
    
%% 5. RUN THE MODEL
    [output steady endssn allendssn N0 MB ODEtype] = SOM_RunModel(MI,RunType);

%% 6. RECORD MODEL OUTPUT
  % Each model run of a simulation produces:
      % "output" (all data)
      % "steady" (steady-state year data)
      % "endssn" (end-season data for the steady-state year)
      % "allednssn" (endssn data from throughout the run)
      % "N0" (initial conditions)
      
   SteadyCell{itercounter} = steady;  
   EndssnCell{itercounter} = endssn;
   AllednssnCell{itercounter} = allendssn;
   N0Cell{itercounter} = N0;    
   MBV(itercounter,1) = MB;
   ODEtypeCell{itercounter} = ODEtype;   

end  % End loop iterating over model simulations

% Make a result vector based on all of the model runs
 results = SOM_UpdateResults(EndssnCell,SteadyCell);   
 steady = SteadyCell{max(lenEF,lenBF)};        % the parfor loop removes 
 endssn = EndssnCell{max(lenEF,lenBF)};        % certain variables, so 
 allendssn = AllednssnCell{max(lenEF,lenBF)};  % redefine them here
 N0 =  N0Cell{max(lenEF,lenBF)};
 ODEtype = ODEtypeCell{max(lenEF,lenBF)};

 SuccessVector = [];
 nanindex = isnan(results.summer.exp.Fru.d15N); % Find models run that returned NaN values
 SuccessVector(nanindex) = 0; SuccessVector(~nanindex) = 1;
 % Display whether any of the model runs were unsuccessful. This can happen if 
 % the model is run at low resolution and accumulates negative concentrations. 
 if sum(SuccessVector)==length(BMIterList)      
       RUNSTAT = 'SUCCESS: All iterations returned non-NaN values';
 else; RUNSTAT = sprintf('FAILURE OF %s ITERATION(S)',num2str(length(BMIterList)-sum(SuccessVector)));
 end 
 display(RUNSTAT)
  
% If running on single, output is made
% If running on parallel, have to give output
 if exist('output','var'); else output = NaN; itercounter = NaN; end
 
% Before saving the file, re-generate the initial inputs
 MI = struct();  MI = SOM_GenerateInputs(Input0);
if itercounter == 1
    MI = SOM_UpdateInputParameters(MI,{'EkmanCDWTransport'},EkIterList,itercounter); % Update Ekman pumping
    MI = SOM_UpdateInputParameters(MI,{'MixTmnCDWBnd'},BMIterList,itercounter);      % Update Basal mixing
    MI = SOM_UpdateInputParameters(MI,{'CDWN14','CDWN15'},CDWIterList,itercounter);
    MI = SOM_UpdateInputParameters(MI,{'DtmKnNO3'},KwIterList,itercounter);
    if ReduceSummerAndWinterMLD == 1    % Reduce the MLD of both summer and winter
        MI = SOM_UpdateInputParameters(MI,{'MLDSummer','MLDWinter'},MLDIterList,itercounter); % Update the depth of the mixed layer       
    elseif ReduceSummerAndWinterMLD == 0  % Reduce the MLD of only summer
        MI = SOM_UpdateInputParameters(MI,{'MLDSummer'},MLDIterList,itercounter); % Update the depth of the mixed layer
    end  
end 
 
SaveName = {[SaveName{:} '_' ODEtype]};

%% 7. SAVE MODEL RESULTS
% Do not save the structures OutputCell, SteadyCell, EndssnCell,
% AllednssnCell, or N0Cell, as they are enormous. 

% Save the model results
save([SaveName{:} '_' RunType '_' num2str(round(MI.ModelLength,1)) 'yr'],'BM0', 'BMIterList','BoundaryFactor', 'Ek0','EkIterList', 'EkmanFactor','lenBF','lenEF','Input0', 'InputTitleNumber', 'IterationList','MI', 'N0', 'RunNCycle','SupplyVector','CDWFactor', 'Sv', 'endssn','fineset','coarseset','output', 'results', 'steady','allendssn','SuccessVector','MLDFactor','RUNSTAT','MBV','-v7.3');
display(sprintf('Saved %s',[SaveName{:} '_' RunType '_' num2str(round(MI.ModelLength,1)) 'yr']));
    
end


