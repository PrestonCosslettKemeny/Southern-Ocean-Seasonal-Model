function [output steady endssn allendssn] = SOM_OrganizeModelResults(t,Nf,MI)

% This function organizes the output of the model into a series of 
% structures to enable easy plotting. Define: 
%   output: model results at all points in time
%   steady: model results in the steady-state year 
%   allendssn: model results at the end of all seasons
%   endssn: model results at the end of seasons in the steady-state year

Rair = MI.Rair;
SOM_DeclareVariableIndex % Declare variable index

%% 1: DEFINE OUTPUT STRUCTURE, ALL MODEL RESULTS

output.day = t;
output.NO3.Srf.N14 = Nf(:,iSrfNO3N14);      % 1: Surface NO3 N14
output.NO3.Srf.N15 = Nf(:,iSrfNO3N15);      % 2: Surface NO3 N15
output.NO3.Tmn.N14 = Nf(:,iTmnNO3N14);      % 3: Tmin NO3 N14
output.NO3.Tmn.N15 = Nf(:,iTmnNO3N15);      % 4: Tmin NO3 N15
output.NH4.Srf.N14 = Nf(:,iSrfNH4N14);      % 5: Surface NH4 N14
output.NH4.Srf.N15 = Nf(:,iSrfNH4N15);      % 6: Surface NH4 N15
output.NH4.Tmn.N14 = Nf(:,iTmnNH4N14);      % 19: Tmin NH4 N14
output.NH4.Tmn.N15 = Nf(:,iTmnNH4N15);      % 20: Tmin NH4 N15
output.Dtm.Srf.N14 = Nf(:,iSrfDtmN14);      % 7: Diatom N14
output.Dtm.Srf.N15 = Nf(:,iSrfDtmN15);      % 8: Diatom N15  
output.Fru.Srf.N14 = Nf(:,iSrfDtmFrustN14); % 25: Diatom N14
output.Fru.Srf.N15 = Nf(:,iSrfDtmFrustN15); % 26: Diatom N15  
output.Zoo.Srf.N14 = Nf(:,iSrfZooN14);      % 9: Zooplankton N14
output.Zoo.Srf.N15 = Nf(:,iSrfZooN15);      % 10: Zooplankton N15
output.NDm.Srf.N14 = Nf(:,iSrfNDmN14);      % 11: Non-diatom N14
output.NDm.Srf.N15 = Nf(:,iSrfNDmN15);      % 12: Non-diatom N15 

        % Derived variables
        output.PaN.Srf.N14 = output.Dtm.Srf.N14 + output.Fru.Srf.N14 + output.Zoo.Srf.N14 + output.NDm.Srf.N14;
        output.PaN.Srf.N15 = output.Dtm.Srf.N15 + output.Fru.Srf.N15 + output.Zoo.Srf.N15 + output.NDm.Srf.N15;
        output.Nit.Srf.N14 = output.Dtm.Srf.N14 + output.Zoo.Srf.N14 + output.NDm.Srf.N14 + output.NH4.Srf.N14;
        output.Nit.Srf.N15 = output.Dtm.Srf.N15 + output.Zoo.Srf.N15 + output.NDm.Srf.N15 + output.NH4.Srf.N15;
        output.Nit.Tmn.N14 = output.NH4.Tmn.N14;
        output.Nit.Tmn.N15 = output.NH4.Tmn.N15;
        
        % Calculate Conc and d15N for each parameter
        output.NO3.Srf.Conc = output.NO3.Srf.N15 +  output.NO3.Srf.N14; output.NO3.Srf.d15N = (output.NO3.Srf.N15./output.NO3.Srf.N14/Rair-1)*1000;
        output.NO3.Tmn.Conc = output.NO3.Tmn.N15 +  output.NO3.Tmn.N14; output.NO3.Tmn.d15N = (output.NO3.Tmn.N15./output.NO3.Tmn.N14/Rair-1)*1000;
        output.NH4.Srf.Conc = output.NH4.Srf.N15 +  output.NH4.Srf.N14; output.NH4.Srf.d15N = (output.NH4.Srf.N15./output.NH4.Srf.N14/Rair-1)*1000; 
        output.NH4.Tmn.Conc = output.NH4.Tmn.N15 +  output.NH4.Tmn.N14; output.NH4.Tmn.d15N = (output.NH4.Tmn.N15./output.NH4.Tmn.N14/Rair-1)*1000; 
        output.Dtm.Srf.Conc = output.Dtm.Srf.N15 +  output.Dtm.Srf.N14; output.Dtm.Srf.d15N = (output.Dtm.Srf.N15./output.Dtm.Srf.N14/Rair-1)*1000;
        output.Fru.Srf.Conc = output.Fru.Srf.N15 +  output.Fru.Srf.N14; output.Fru.Srf.d15N = (output.Fru.Srf.N15./output.Fru.Srf.N14/Rair-1)*1000;
        output.Zoo.Srf.Conc = output.Zoo.Srf.N15 +  output.Zoo.Srf.N14; output.Zoo.Srf.d15N = (output.Zoo.Srf.N15./output.Zoo.Srf.N14/Rair-1)*1000;
        output.NDm.Srf.Conc = output.NDm.Srf.N15 +  output.NDm.Srf.N14; output.NDm.Srf.d15N = (output.NDm.Srf.N15./output.NDm.Srf.N14/Rair-1)*1000;
        output.PaN.Srf.Conc = output.PaN.Srf.N15 +  output.PaN.Srf.N14; output.PaN.Srf.d15N = (output.PaN.Srf.N15./output.PaN.Srf.N14/Rair-1)*1000;             
        output.Nit.Srf.Conc = output.Nit.Srf.N15 +  output.Nit.Srf.N14; output.Nit.Srf.d15N = (output.Nit.Srf.N15./output.Nit.Srf.N14/Rair-1)*1000; 
        output.Nit.Tmn.Conc = output.Nit.Tmn.N15 +  output.Nit.Tmn.N14; output.Nit.Tmn.d15N = (output.Nit.Tmn.N15./output.Nit.Tmn.N14/Rair-1)*1000; 
        
output.exp.Dtm.N14 = Nf(:,iExpDtmN14);      %  13: Diatom biomass export production N14
output.exp.Dtm.N15 = Nf(:,iExpDtmN15);      %  14: Diatom biomass export production N15
output.exp.Fru.N14 = Nf(:,iExpDtmFrustN14); %  23: Diatom frustule export production N14
output.exp.Fru.N15 = Nf(:,iExpDtmFrustN15); %  24: Diatom frustule export production N15
output.exp.Zoo.N14 = Nf(:,iExpZooN14);      %  15: Zooplankton export production N14
output.exp.Zoo.N15 = Nf(:,iExpZooN15);      %  16: Zooplankton export production N15

% Here is the total mass balance of the system!
output.MB.OAZIn.N14 = Nf(:,iInN14);
output.MB.OAZIn.N15 = Nf(:,iInN15);
output.MB.OAZOt.N14 = Nf(:,iOutN14);
output.MB.OAZOt.N15 = Nf(:,iOutN15);

   % Derived variables
    output.exp.Tot.N14 = output.exp.Dtm.N14 + output.exp.Fru.N14 + output.exp.Zoo.N14; 
    output.exp.Tot.N15 = output.exp.Dtm.N15 + output.exp.Fru.N15 + output.exp.Zoo.N15;
    % Calculate Conc and d15N for each export parameter
    output.exp.Dtm.Conc = output.exp.Dtm.N14+output.exp.Dtm.N15; output.exp.Dtm.d15N = (output.exp.Dtm.N15./output.exp.Dtm.N14/Rair-1)*1000;
    output.exp.Fru.Conc = output.exp.Fru.N14+output.exp.Fru.N15; output.exp.Fru.d15N = (output.exp.Fru.N15./output.exp.Fru.N14/Rair-1)*1000;
    output.exp.Zoo.Conc = output.exp.Zoo.N14+output.exp.Zoo.N15; output.exp.Zoo.d15N = (output.exp.Zoo.N15./output.exp.Zoo.N14/Rair-1)*1000;
    output.exp.Tot.Conc = output.exp.Tot.N14+output.exp.Tot.N15; output.exp.Tot.d15N = (output.exp.Tot.N15./output.exp.Tot.N14/Rair-1)*1000;
 
output.SummerSeason = MI.SummerSeason;    

%% 2: DEFINE STEADY STRUCTURE, MODEL RESULTS FOR STEADY-STATE YEAR

timescaler = 365; % Normally t is in days and we want it into years, 
                  % so we divide by 365

% The SS index is the first day of summer, which occurs when there
% have been an integer number of days (the summer condition
% in the model is rem(T,365)<SummerSeason. For a 50-year model run, 
% the first day of summer is T=49 years.
SS_index = find(round(t,10)/timescaler==(MI.ModelLength-1));

% By the same logic, the last day of winter is the timestep before the 
% final step of the model. This is the final timestep before it becomes
% summertime conditions (in the case when the model is run for an 
% integer number of years. 
EW_index = find(round(t,10)/timescaler==MI.ModelLength)-1;

% We also need to know the day that the season transitions 
% from summertime to wintertime
ES_index = find(round(t,10)==t(SS_index)+MI.SummerSeason)-1; % Index at which summer ends
SW_index = ES_index+1;


% For N parameters, sample the output for N15, N14, Conc, and d15N
steady.day          = output.day(SS_index:EW_index);
steady.NO3.Srf.N14  = output.NO3.Srf.N14(SS_index:EW_index); steady.NO3.Srf.N15  = output.NO3.Srf.N15(SS_index:EW_index); steady.NO3.Srf.Conc = output.NO3.Srf.Conc(SS_index:EW_index); steady.NO3.Srf.d15N = output.NO3.Srf.d15N(SS_index:EW_index);
steady.NO3.Tmn.N14  = output.NO3.Tmn.N14(SS_index:EW_index); steady.NO3.Tmn.N15  = output.NO3.Tmn.N15(SS_index:EW_index); steady.NO3.Tmn.Conc = output.NO3.Tmn.Conc(SS_index:EW_index); steady.NO3.Tmn.d15N = output.NO3.Tmn.d15N(SS_index:EW_index);
steady.NH4.Srf.N14  = output.NH4.Srf.N14(SS_index:EW_index); steady.NH4.Srf.N15  = output.NH4.Srf.N15(SS_index:EW_index); steady.NH4.Srf.Conc = output.NH4.Srf.Conc(SS_index:EW_index); steady.NH4.Srf.d15N = output.NH4.Srf.d15N(SS_index:EW_index);
steady.NH4.Tmn.N14  = output.NH4.Tmn.N14(SS_index:EW_index); steady.NH4.Tmn.N15  = output.NH4.Tmn.N15(SS_index:EW_index); steady.NH4.Tmn.Conc = output.NH4.Tmn.Conc(SS_index:EW_index); steady.NH4.Tmn.d15N = output.NH4.Tmn.d15N(SS_index:EW_index);
steady.Dtm.Srf.N14  = output.Dtm.Srf.N14(SS_index:EW_index); steady.Dtm.Srf.N15  = output.Dtm.Srf.N15(SS_index:EW_index); steady.Dtm.Srf.Conc = output.Dtm.Srf.Conc(SS_index:EW_index); steady.Dtm.Srf.d15N = output.Dtm.Srf.d15N(SS_index:EW_index);
steady.Fru.Srf.N14  = output.Fru.Srf.N14(SS_index:EW_index); steady.Fru.Srf.N15  = output.Fru.Srf.N15(SS_index:EW_index); steady.Fru.Srf.Conc = output.Fru.Srf.Conc(SS_index:EW_index); steady.Fru.Srf.d15N = output.Fru.Srf.d15N(SS_index:EW_index);
steady.Zoo.Srf.N14  = output.Zoo.Srf.N14(SS_index:EW_index); steady.Zoo.Srf.N15  = output.Zoo.Srf.N15(SS_index:EW_index); steady.Zoo.Srf.Conc = output.Zoo.Srf.Conc(SS_index:EW_index); steady.Zoo.Srf.d15N = output.Zoo.Srf.d15N(SS_index:EW_index);
steady.NDm.Srf.N14  = output.NDm.Srf.N14(SS_index:EW_index); steady.NDm.Srf.N15  = output.NDm.Srf.N15(SS_index:EW_index); steady.NDm.Srf.Conc = output.NDm.Srf.Conc(SS_index:EW_index); steady.NDm.Srf.d15N = output.NDm.Srf.d15N(SS_index:EW_index);
steady.PaN.Srf.N14  = output.PaN.Srf.N14(SS_index:EW_index); steady.PaN.Srf.N15  = output.PaN.Srf.N15(SS_index:EW_index); steady.PaN.Srf.Conc = output.PaN.Srf.Conc(SS_index:EW_index); steady.PaN.Srf.d15N = output.PaN.Srf.d15N(SS_index:EW_index);
steady.Nit.Srf.N14  = output.Nit.Srf.N14(SS_index:EW_index); steady.Nit.Srf.N15  = output.Nit.Srf.N15(SS_index:EW_index); steady.Nit.Srf.Conc = output.Nit.Srf.Conc(SS_index:EW_index); steady.Nit.Srf.d15N = output.Nit.Srf.d15N(SS_index:EW_index);
steady.Nit.Tmn.N14  = output.Nit.Tmn.N14(SS_index:EW_index); steady.Nit.Tmn.N15  = output.Nit.Tmn.N15(SS_index:EW_index); steady.Nit.Tmn.Conc = output.Nit.Tmn.Conc(SS_index:EW_index); steady.Nit.Tmn.d15N = output.Nit.Tmn.d15N(SS_index:EW_index);

% For the export, substract the value at the start of the steady-state
% year, then re-calculate the concentration and d15N of the export.
steady.exp.Dtm.N14 = output.exp.Dtm.N14(SS_index:EW_index)-output.exp.Dtm.N14(SS_index-1);
steady.exp.Dtm.N15 = output.exp.Dtm.N15(SS_index:EW_index)-output.exp.Dtm.N15(SS_index-1);
steady.exp.Fru.N14 = output.exp.Fru.N14(SS_index:EW_index)-output.exp.Fru.N14(SS_index-1);
steady.exp.Fru.N15 = output.exp.Fru.N15(SS_index:EW_index)-output.exp.Fru.N15(SS_index-1);
steady.exp.Zoo.N14 = output.exp.Zoo.N14(SS_index:EW_index)-output.exp.Zoo.N14(SS_index-1);
steady.exp.Zoo.N15 = output.exp.Zoo.N15(SS_index:EW_index)-output.exp.Zoo.N15(SS_index-1);
steady.exp.Tot.N14 = output.exp.Tot.N14(SS_index:EW_index)-output.exp.Tot.N14(SS_index-1);
steady.exp.Tot.N15 = output.exp.Tot.N15(SS_index:EW_index)-output.exp.Tot.N15(SS_index-1);
    steady.exp.Dtm.Conc = steady.exp.Dtm.N14+steady.exp.Dtm.N15; steady.exp.Dtm.d15N = (steady.exp.Dtm.N15./steady.exp.Dtm.N14/Rair-1)*1000;
    steady.exp.Fru.Conc = steady.exp.Fru.N14+steady.exp.Fru.N15; steady.exp.Fru.d15N = (steady.exp.Fru.N15./steady.exp.Fru.N14/Rair-1)*1000;
    steady.exp.Zoo.Conc = steady.exp.Zoo.N14+steady.exp.Zoo.N15; steady.exp.Zoo.d15N = (steady.exp.Zoo.N15./steady.exp.Zoo.N14/Rair-1)*1000;
    steady.exp.Tot.Conc = steady.exp.Tot.N14+steady.exp.Tot.N15; steady.exp.Tot.d15N = (steady.exp.Tot.N15./steady.exp.Tot.N14/Rair-1)*1000;

    
%% 3: DEFINE ENDSSN STRUCTURE, MODEL RESULTS FOR END-SEASONS OF STEADY-STATE YEAR

% For N parameters, sample the output for N15, N14, Conc, and d15N
endssn.summer.NO3.Srf.N14  = output.NO3.Srf.N14(ES_index);  endssn.winter.NO3.Srf.N14  = output.NO3.Srf.N14(EW_index);
endssn.summer.NO3.Srf.N15  = output.NO3.Srf.N15(ES_index);  endssn.winter.NO3.Srf.N15  = output.NO3.Srf.N15(EW_index);
endssn.summer.NO3.Srf.Conc = output.NO3.Srf.Conc(ES_index); endssn.winter.NO3.Srf.Conc = output.NO3.Srf.Conc(EW_index);
endssn.summer.NO3.Srf.d15N = output.NO3.Srf.d15N(ES_index); endssn.winter.NO3.Srf.d15N = output.NO3.Srf.d15N(EW_index);
endssn.summer.NO3.Tmn.N14  = output.NO3.Tmn.N14(ES_index);  endssn.winter.NO3.Tmn.N14  = output.NO3.Tmn.N14(EW_index);
endssn.summer.NO3.Tmn.N15  = output.NO3.Tmn.N15(ES_index);  endssn.winter.NO3.Tmn.N15  = output.NO3.Tmn.N15(EW_index);
endssn.summer.NO3.Tmn.Conc = output.NO3.Tmn.Conc(ES_index); endssn.winter.NO3.Tmn.Conc = output.NO3.Tmn.Conc(EW_index);
endssn.summer.NO3.Tmn.d15N = output.NO3.Tmn.d15N(ES_index); endssn.winter.NO3.Tmn.d15N = output.NO3.Tmn.d15N(EW_index);
endssn.summer.NH4.Srf.N14  = output.NH4.Srf.N14(ES_index);  endssn.winter.NH4.Srf.N14  = output.NH4.Srf.N14(EW_index);
endssn.summer.NH4.Srf.N15  = output.NH4.Srf.N15(ES_index);  endssn.winter.NH4.Srf.N15  = output.NH4.Srf.N15(EW_index);
endssn.summer.NH4.Srf.Conc = output.NH4.Srf.Conc(ES_index); endssn.winter.NH4.Srf.Conc = output.NH4.Srf.Conc(EW_index);
endssn.summer.NH4.Srf.d15N = output.NH4.Srf.d15N(ES_index); endssn.winter.NH4.Srf.d15N = output.NH4.Srf.d15N(EW_index);
endssn.summer.NH4.Tmn.N14  = output.NH4.Tmn.N14(ES_index);  endssn.winter.NH4.Tmn.N14  = output.NH4.Tmn.N14(EW_index);
endssn.summer.NH4.Tmn.N15  = output.NH4.Tmn.N15(ES_index);  endssn.winter.NH4.Tmn.N15  = output.NH4.Tmn.N15(EW_index);
endssn.summer.NH4.Tmn.Conc = output.NH4.Tmn.Conc(ES_index); endssn.winter.NH4.Tmn.Conc = output.NH4.Tmn.Conc(EW_index);
endssn.summer.NH4.Tmn.d15N = output.NH4.Tmn.d15N(ES_index); endssn.winter.NH4.Tmn.d15N = output.NH4.Tmn.d15N(EW_index);
endssn.summer.Dtm.Srf.N14  = output.Dtm.Srf.N14(ES_index);  endssn.winter.Dtm.Srf.N14  = output.Dtm.Srf.N14(EW_index);
endssn.summer.Dtm.Srf.N15  = output.Dtm.Srf.N15(ES_index);  endssn.winter.Dtm.Srf.N15  = output.Dtm.Srf.N15(EW_index);
endssn.summer.Dtm.Srf.Conc = output.Dtm.Srf.Conc(ES_index); endssn.winter.Dtm.Srf.Conc = output.Dtm.Srf.Conc(EW_index);
endssn.summer.Dtm.Srf.d15N = output.Dtm.Srf.d15N(ES_index); endssn.winter.Dtm.Srf.d15N = output.Dtm.Srf.d15N(EW_index);
endssn.summer.Fru.Srf.N14  = output.Fru.Srf.N14(ES_index);  endssn.winter.Fru.Srf.N14  = output.Fru.Srf.N14(EW_index);
endssn.summer.Fru.Srf.N15  = output.Fru.Srf.N15(ES_index);  endssn.winter.Fru.Srf.N15  = output.Fru.Srf.N15(EW_index);
endssn.summer.Fru.Srf.Conc = output.Fru.Srf.Conc(ES_index); endssn.winter.Fru.Srf.Conc = output.Fru.Srf.Conc(EW_index);
endssn.summer.Fru.Srf.d15N = output.Fru.Srf.d15N(ES_index); endssn.winter.Fru.Srf.d15N = output.Fru.Srf.d15N(EW_index);
endssn.summer.Zoo.Srf.N14  = output.Zoo.Srf.N14(ES_index);  endssn.winter.Zoo.Srf.N14  = output.Zoo.Srf.N14(EW_index);
endssn.summer.Zoo.Srf.N15  = output.Zoo.Srf.N15(ES_index);  endssn.winter.Zoo.Srf.N15  = output.Zoo.Srf.N15(EW_index);
endssn.summer.Zoo.Srf.Conc = output.Zoo.Srf.Conc(ES_index); endssn.winter.Zoo.Srf.Conc = output.Zoo.Srf.Conc(EW_index);
endssn.summer.Zoo.Srf.d15N = output.Zoo.Srf.d15N(ES_index); endssn.winter.Zoo.Srf.d15N = output.Zoo.Srf.d15N(EW_index);
endssn.summer.NDm.Srf.N14  = output.NDm.Srf.N14(ES_index);  endssn.winter.NDm.Srf.N14  = output.NDm.Srf.N14(EW_index);
endssn.summer.NDm.Srf.N15  = output.NDm.Srf.N15(ES_index);  endssn.winter.NDm.Srf.N15  = output.NDm.Srf.N15(EW_index);
endssn.summer.NDm.Srf.Conc = output.NDm.Srf.Conc(ES_index); endssn.winter.NDm.Srf.Conc = output.NDm.Srf.Conc(EW_index);
endssn.summer.NDm.Srf.d15N = output.NDm.Srf.d15N(ES_index); endssn.winter.NDm.Srf.d15N = output.NDm.Srf.d15N(EW_index);
endssn.summer.PaN.Srf.N14  = output.PaN.Srf.N14(ES_index);  endssn.winter.PaN.Srf.N14  = output.PaN.Srf.N14(EW_index);
endssn.summer.PaN.Srf.N15  = output.PaN.Srf.N15(ES_index);  endssn.winter.PaN.Srf.N15  = output.PaN.Srf.N15(EW_index);
endssn.summer.PaN.Srf.Conc = output.PaN.Srf.Conc(ES_index); endssn.winter.PaN.Srf.Conc = output.PaN.Srf.Conc(EW_index);
endssn.summer.PaN.Srf.d15N = output.PaN.Srf.d15N(ES_index); endssn.winter.PaN.Srf.d15N = output.PaN.Srf.d15N(EW_index);
endssn.summer.Nit.Srf.N14  = output.Nit.Srf.N14(ES_index);  endssn.winter.Nit.Srf.N14  = output.Nit.Srf.N14(EW_index);
endssn.summer.Nit.Srf.N15  = output.Nit.Srf.N15(ES_index);  endssn.winter.Nit.Srf.N15  = output.Nit.Srf.N15(EW_index);
endssn.summer.Nit.Srf.Conc = output.Nit.Srf.Conc(ES_index); endssn.winter.Nit.Srf.Conc = output.Nit.Srf.Conc(EW_index);
endssn.summer.Nit.Srf.d15N = output.Nit.Srf.d15N(ES_index); endssn.winter.Nit.Srf.d15N = output.Nit.Srf.d15N(EW_index);
endssn.summer.Nit.Tmn.N14  = output.Nit.Tmn.N14(ES_index);  endssn.winter.Nit.Tmn.N14  = output.Nit.Tmn.N14(EW_index);
endssn.summer.Nit.Tmn.N15  = output.Nit.Tmn.N15(ES_index);  endssn.winter.Nit.Tmn.N15  = output.Nit.Tmn.N15(EW_index);
endssn.summer.Nit.Tmn.Conc = output.Nit.Tmn.Conc(ES_index); endssn.winter.Nit.Tmn.Conc = output.Nit.Tmn.Conc(EW_index);
endssn.summer.Nit.Tmn.d15N = output.Nit.Tmn.d15N(ES_index); endssn.winter.Nit.Tmn.d15N = output.Nit.Tmn.d15N(EW_index);

% For the export, substract the value at the start of the steady-state
% year, then re-calculate the concentration and d15N of the export.
endssn.summer.exp.Dtm.N14 = output.exp.Dtm.N14(ES_index)-output.exp.Dtm.N14(SS_index-1); endssn.winter.exp.Dtm.N14 = output.exp.Dtm.N14(EW_index)-output.exp.Dtm.N14(SS_index-1);
endssn.summer.exp.Dtm.N15 = output.exp.Dtm.N15(ES_index)-output.exp.Dtm.N15(SS_index-1); endssn.winter.exp.Dtm.N15 = output.exp.Dtm.N15(EW_index)-output.exp.Dtm.N15(SS_index-1);
endssn.summer.exp.Fru.N14 = output.exp.Fru.N14(ES_index)-output.exp.Fru.N14(SS_index-1); endssn.winter.exp.Fru.N14 = output.exp.Fru.N14(EW_index)-output.exp.Fru.N14(SS_index-1);
endssn.summer.exp.Fru.N15 = output.exp.Fru.N15(ES_index)-output.exp.Fru.N15(SS_index-1); endssn.winter.exp.Fru.N15 = output.exp.Fru.N15(EW_index)-output.exp.Fru.N15(SS_index-1);
endssn.summer.exp.Zoo.N14 = output.exp.Zoo.N14(ES_index)-output.exp.Zoo.N14(SS_index-1); endssn.winter.exp.Zoo.N14 = output.exp.Zoo.N14(EW_index)-output.exp.Zoo.N14(SS_index-1);
endssn.summer.exp.Zoo.N15 = output.exp.Zoo.N15(ES_index)-output.exp.Zoo.N15(SS_index-1); endssn.winter.exp.Zoo.N15 = output.exp.Zoo.N15(EW_index)-output.exp.Zoo.N15(SS_index-1);
endssn.summer.exp.Tot.N14 = output.exp.Tot.N14(ES_index)-output.exp.Tot.N14(SS_index-1); endssn.winter.exp.Tot.N14 = output.exp.Tot.N14(EW_index)-output.exp.Tot.N14(SS_index-1);
endssn.summer.exp.Tot.N15 = output.exp.Tot.N15(ES_index)-output.exp.Tot.N15(SS_index-1); endssn.winter.exp.Tot.N15 = output.exp.Tot.N15(EW_index)-output.exp.Tot.N15(SS_index-1);
    endssn.summer.exp.Dtm.Conc = endssn.summer.exp.Dtm.N14+endssn.summer.exp.Dtm.N15; endssn.summer.exp.Dtm.d15N = (endssn.summer.exp.Dtm.N15./endssn.summer.exp.Dtm.N14/Rair-1)*1000;
    endssn.summer.exp.Fru.Conc = endssn.summer.exp.Fru.N14+endssn.summer.exp.Fru.N15; endssn.summer.exp.Fru.d15N = (endssn.summer.exp.Fru.N15./endssn.summer.exp.Fru.N14/Rair-1)*1000;
    endssn.summer.exp.Zoo.Conc = endssn.summer.exp.Zoo.N14+endssn.summer.exp.Zoo.N15; endssn.summer.exp.Zoo.d15N = (endssn.summer.exp.Zoo.N15./endssn.summer.exp.Zoo.N14/Rair-1)*1000;
    endssn.summer.exp.Tot.Conc = endssn.summer.exp.Tot.N14+endssn.summer.exp.Tot.N15; endssn.summer.exp.Tot.d15N = (endssn.summer.exp.Tot.N15./endssn.summer.exp.Tot.N14/Rair-1)*1000;
    endssn.winter.exp.Dtm.Conc = endssn.winter.exp.Dtm.N14+endssn.winter.exp.Dtm.N15; endssn.winter.exp.Dtm.d15N = (endssn.winter.exp.Dtm.N15./endssn.winter.exp.Dtm.N14/Rair-1)*1000;
    endssn.winter.exp.Fru.Conc = endssn.winter.exp.Fru.N14+endssn.winter.exp.Fru.N15; endssn.winter.exp.Fru.d15N = (endssn.winter.exp.Fru.N15./endssn.winter.exp.Fru.N14/Rair-1)*1000;
    endssn.winter.exp.Zoo.Conc = endssn.winter.exp.Zoo.N14+endssn.winter.exp.Zoo.N15; endssn.winter.exp.Zoo.d15N = (endssn.winter.exp.Zoo.N15./endssn.winter.exp.Zoo.N14/Rair-1)*1000;
    endssn.winter.exp.Tot.Conc = endssn.winter.exp.Tot.N14+endssn.winter.exp.Tot.N15; endssn.winter.exp.Tot.d15N = (endssn.winter.exp.Tot.N15./endssn.winter.exp.Tot.N14/Rair-1)*1000;
    

%% 4: DEFINE ALLENDSSN STRUCTURE, MODEL RESULTS FOR ALL END-SEASONS

% We need all of the indexes for the first and last days of summer and winter
full_EW_index = find(rem(t/timescaler,1)==0)-1; % Get all of the last days of winter (ModelYears+1 long)
all_EW_index = full_EW_index(2:end);     % Throw away the first value (year 1, time 0)

full_SS_index = find(rem(t/timescaler,1)==0);   % Get all of the first days of summer (ModelYears+1 long)
all_SS_index = full_SS_index(1:end-1);   % Thow away the last value (year 100)

% Calculate the end days of summer, ignoring the last value (because the model ends in winter)
allendsummerdays =  t(all_SS_index)+MI.SummerSeason;                     % Get days of start summer, add length of summer
all_ES_index = find(ismember(round(t,10),round(allendsummerdays,10)))-1; % Find indicies of those days

all_SW_index = all_ES_index+1; % Add one to end-summer to get to start winter

% For N parameters, sample the output for N15, N14, Conc, and d15N
allendssn.summer.day          = output.day(all_ES_index);          allendssn.winter.day          = output.day(all_EW_index);
allendssn.summer.NO3.Srf.N14  = output.NO3.Srf.N14(all_ES_index);  allendssn.winter.NO3.Srf.N14  = output.NO3.Srf.N14(all_EW_index);
allendssn.summer.NO3.Srf.N15  = output.NO3.Srf.N15(all_ES_index);  allendssn.winter.NO3.Srf.N15  = output.NO3.Srf.N15(all_EW_index);
allendssn.summer.NO3.Srf.Conc = output.NO3.Srf.Conc(all_ES_index); allendssn.winter.NO3.Srf.Conc = output.NO3.Srf.Conc(all_EW_index);
allendssn.summer.NO3.Srf.d15N = output.NO3.Srf.d15N(all_ES_index); allendssn.winter.NO3.Srf.d15N = output.NO3.Srf.d15N(all_EW_index);
allendssn.summer.NO3.Tmn.N14  = output.NO3.Tmn.N14(all_ES_index);  allendssn.winter.NO3.Tmn.N14  = output.NO3.Tmn.N14(all_EW_index);
allendssn.summer.NO3.Tmn.N15  = output.NO3.Tmn.N15(all_ES_index);  allendssn.winter.NO3.Tmn.N15  = output.NO3.Tmn.N15(all_EW_index);
allendssn.summer.NO3.Tmn.Conc = output.NO3.Tmn.Conc(all_ES_index); allendssn.winter.NO3.Tmn.Conc = output.NO3.Tmn.Conc(all_EW_index);
allendssn.summer.NO3.Tmn.d15N = output.NO3.Tmn.d15N(all_ES_index); allendssn.winter.NO3.Tmn.d15N = output.NO3.Tmn.d15N(all_EW_index);
allendssn.summer.NH4.Srf.N14  = output.NH4.Srf.N14(all_ES_index);  allendssn.winter.NH4.Srf.N14  = output.NH4.Srf.N14(all_EW_index);
allendssn.summer.NH4.Srf.N15  = output.NH4.Srf.N15(all_ES_index);  allendssn.winter.NH4.Srf.N15  = output.NH4.Srf.N15(all_EW_index);
allendssn.summer.NH4.Srf.Conc = output.NH4.Srf.Conc(all_ES_index); allendssn.winter.NH4.Srf.Conc = output.NH4.Srf.Conc(all_EW_index);
allendssn.summer.NH4.Srf.d15N = output.NH4.Srf.d15N(all_ES_index); allendssn.winter.NH4.Srf.d15N = output.NH4.Srf.d15N(all_EW_index);
allendssn.summer.NH4.Tmn.N14  = output.NH4.Tmn.N14(all_ES_index);  allendssn.winter.NH4.Tmn.N14  = output.NH4.Tmn.N14(all_EW_index);
allendssn.summer.NH4.Tmn.N15  = output.NH4.Tmn.N15(all_ES_index);  allendssn.winter.NH4.Tmn.N15  = output.NH4.Tmn.N15(all_EW_index);
allendssn.summer.NH4.Tmn.Conc = output.NH4.Tmn.Conc(all_ES_index); allendssn.winter.NH4.Tmn.Conc = output.NH4.Tmn.Conc(all_EW_index);
allendssn.summer.NH4.Tmn.d15N = output.NH4.Tmn.d15N(all_ES_index); allendssn.winter.NH4.Tmn.d15N = output.NH4.Tmn.d15N(all_EW_index);
allendssn.summer.Dtm.Srf.N14  = output.Dtm.Srf.N14(all_ES_index);  allendssn.winter.Dtm.Srf.N14  = output.Dtm.Srf.N14(all_EW_index);
allendssn.summer.Dtm.Srf.N15  = output.Dtm.Srf.N15(all_ES_index);  allendssn.winter.Dtm.Srf.N15  = output.Dtm.Srf.N15(all_EW_index);
allendssn.summer.Dtm.Srf.Conc = output.Dtm.Srf.Conc(all_ES_index); allendssn.winter.Dtm.Srf.Conc = output.Dtm.Srf.Conc(all_EW_index);
allendssn.summer.Dtm.Srf.d15N = output.Dtm.Srf.d15N(all_ES_index); allendssn.winter.Dtm.Srf.d15N = output.Dtm.Srf.d15N(all_EW_index);
allendssn.summer.Fru.Srf.N14  = output.Fru.Srf.N14(all_ES_index);  allendssn.winter.Fru.Srf.N14  = output.Fru.Srf.N14(all_EW_index);
allendssn.summer.Fru.Srf.N15  = output.Fru.Srf.N15(all_ES_index);  allendssn.winter.Fru.Srf.N15  = output.Fru.Srf.N15(all_EW_index);
allendssn.summer.Fru.Srf.Conc = output.Fru.Srf.Conc(all_ES_index); allendssn.winter.Fru.Srf.Conc = output.Fru.Srf.Conc(all_EW_index);
allendssn.summer.Fru.Srf.d15N = output.Fru.Srf.d15N(all_ES_index); allendssn.winter.Fru.Srf.d15N = output.Fru.Srf.d15N(all_EW_index);
allendssn.summer.Zoo.Srf.N14  = output.Zoo.Srf.N14(all_ES_index);  allendssn.winter.Zoo.Srf.N14  = output.Zoo.Srf.N14(all_EW_index);
allendssn.summer.Zoo.Srf.N15  = output.Zoo.Srf.N15(all_ES_index);  allendssn.winter.Zoo.Srf.N15  = output.Zoo.Srf.N15(all_EW_index);
allendssn.summer.Zoo.Srf.Conc = output.Zoo.Srf.Conc(all_ES_index); allendssn.winter.Zoo.Srf.Conc = output.Zoo.Srf.Conc(all_EW_index);
allendssn.summer.Zoo.Srf.d15N = output.Zoo.Srf.d15N(all_ES_index); allendssn.winter.Zoo.Srf.d15N = output.Zoo.Srf.d15N(all_EW_index);
allendssn.summer.NDm.Srf.N14  = output.NDm.Srf.N14(all_ES_index);  allendssn.winter.NDm.Srf.N14  = output.NDm.Srf.N14(all_EW_index);
allendssn.summer.NDm.Srf.N15  = output.NDm.Srf.N15(all_ES_index);  allendssn.winter.NDm.Srf.N15  = output.NDm.Srf.N15(all_EW_index);
allendssn.summer.NDm.Srf.Conc = output.NDm.Srf.Conc(all_ES_index); allendssn.winter.NDm.Srf.Conc = output.NDm.Srf.Conc(all_EW_index);
allendssn.summer.NDm.Srf.d15N = output.NDm.Srf.d15N(all_ES_index); allendssn.winter.NDm.Srf.d15N = output.NDm.Srf.d15N(all_EW_index);
allendssn.summer.PaN.Srf.N14  = output.PaN.Srf.N14(all_ES_index);  allendssn.winter.PaN.Srf.N14  = output.PaN.Srf.N14(all_EW_index);
allendssn.summer.PaN.Srf.N15  = output.PaN.Srf.N15(all_ES_index);  allendssn.winter.PaN.Srf.N15  = output.PaN.Srf.N15(all_EW_index);
allendssn.summer.PaN.Srf.Conc = output.PaN.Srf.Conc(all_ES_index); allendssn.winter.PaN.Srf.Conc = output.PaN.Srf.Conc(all_EW_index);
allendssn.summer.PaN.Srf.d15N = output.PaN.Srf.d15N(all_ES_index); allendssn.winter.PaN.Srf.d15N = output.PaN.Srf.d15N(all_EW_index);
allendssn.summer.Nit.Srf.N14  = output.Nit.Srf.N14(all_ES_index);  allendssn.winter.Nit.Srf.N14  = output.Nit.Srf.N14(all_EW_index);
allendssn.summer.Nit.Srf.N15  = output.Nit.Srf.N15(all_ES_index);  allendssn.winter.Nit.Srf.N15  = output.Nit.Srf.N15(all_EW_index);
allendssn.summer.Nit.Srf.Conc = output.Nit.Srf.Conc(all_ES_index); allendssn.winter.Nit.Srf.Conc = output.Nit.Srf.Conc(all_EW_index);
allendssn.summer.Nit.Srf.d15N = output.Nit.Srf.d15N(all_ES_index); allendssn.winter.Nit.Srf.d15N = output.Nit.Srf.d15N(all_EW_index);
allendssn.summer.Nit.Tmn.N14  = output.Nit.Tmn.N14(all_ES_index);  allendssn.winter.Tmn.Srf.N14  = output.Nit.Tmn.N14(all_EW_index);
allendssn.summer.Nit.Tmn.N15  = output.Nit.Tmn.N15(all_ES_index);  allendssn.winter.Tmn.Srf.N15  = output.Nit.Tmn.N15(all_EW_index);
allendssn.summer.Nit.Tmn.Conc = output.Nit.Tmn.Conc(all_ES_index); allendssn.winter.Tmn.Srf.Conc = output.Nit.Tmn.Conc(all_EW_index);
allendssn.summer.Nit.Tmn.d15N = output.Nit.Tmn.d15N(all_ES_index); allendssn.winter.Tmn.Srf.d15N = output.Nit.Tmn.d15N(all_EW_index);

% For the export, substract the value at the start of the steady-state year (the index before the first day), then re-calculate the concentration and d15N of the export.
% Because the summer begins on the first index position, we have to do the
% first day differently from the others
allendssn.summer.exp.Dtm.N14(1) = output.exp.Dtm.N14(all_ES_index(1))-0; allendssn.winter.exp.Dtm.N14 = output.exp.Dtm.N14(all_EW_index)-0;
allendssn.summer.exp.Dtm.N15(1) = output.exp.Dtm.N15(all_ES_index(1))-0; allendssn.winter.exp.Dtm.N15 = output.exp.Dtm.N15(all_EW_index)-0;
allendssn.summer.exp.Fru.N14(1) = output.exp.Fru.N14(all_ES_index(1))-0; allendssn.winter.exp.Fru.N14 = output.exp.Fru.N14(all_EW_index)-0;
allendssn.summer.exp.Fru.N15(1) = output.exp.Fru.N15(all_ES_index(1))-0; allendssn.winter.exp.Fru.N15 = output.exp.Fru.N15(all_EW_index)-0;
allendssn.summer.exp.Zoo.N14(1) = output.exp.Zoo.N14(all_ES_index(1))-0; allendssn.winter.exp.Zoo.N14 = output.exp.Zoo.N14(all_EW_index)-0;
allendssn.summer.exp.Zoo.N15(1) = output.exp.Zoo.N15(all_ES_index(1))-0; allendssn.winter.exp.Zoo.N15 = output.exp.Zoo.N15(all_EW_index)-0;
allendssn.summer.exp.Tot.N14(1) = output.exp.Tot.N14(all_ES_index(1))-0; allendssn.winter.exp.Tot.N14 = output.exp.Tot.N14(all_EW_index)-0;
allendssn.summer.exp.Tot.N15(1) = output.exp.Tot.N15(all_ES_index(1))-0; allendssn.winter.exp.Tot.N15 = output.exp.Tot.N15(all_EW_index)-0;

allendssn.summer.exp.Dtm.N14(2:MI.ModelLength) = output.exp.Dtm.N14(all_ES_index(2:end))-output.exp.Dtm.N14(all_SS_index(2:end)-1); allendssn.winter.exp.Dtm.N14 = output.exp.Dtm.N14(all_EW_index(2:end))-output.exp.Dtm.N14(all_SS_index(2:end)-1);
allendssn.summer.exp.Dtm.N15(2:MI.ModelLength) = output.exp.Dtm.N15(all_ES_index(2:end))-output.exp.Dtm.N15(all_SS_index(2:end)-1); allendssn.winter.exp.Dtm.N15 = output.exp.Dtm.N15(all_EW_index(2:end))-output.exp.Dtm.N15(all_SS_index(2:end)-1);
allendssn.summer.exp.Fru.N14(2:MI.ModelLength) = output.exp.Fru.N14(all_ES_index(2:end))-output.exp.Fru.N14(all_SS_index(2:end)-1); allendssn.winter.exp.Fru.N14 = output.exp.Fru.N14(all_EW_index(2:end))-output.exp.Fru.N14(all_SS_index(2:end)-1);
allendssn.summer.exp.Fru.N15(2:MI.ModelLength) = output.exp.Fru.N15(all_ES_index(2:end))-output.exp.Fru.N15(all_SS_index(2:end)-1); allendssn.winter.exp.Fru.N15 = output.exp.Fru.N15(all_EW_index(2:end))-output.exp.Fru.N15(all_SS_index(2:end)-1);
allendssn.summer.exp.Zoo.N14(2:MI.ModelLength) = output.exp.Zoo.N14(all_ES_index(2:end))-output.exp.Zoo.N14(all_SS_index(2:end)-1); allendssn.winter.exp.Zoo.N14 = output.exp.Zoo.N14(all_EW_index(2:end))-output.exp.Zoo.N14(all_SS_index(2:end)-1);
allendssn.summer.exp.Zoo.N15(2:MI.ModelLength) = output.exp.Zoo.N15(all_ES_index(2:end))-output.exp.Zoo.N15(all_SS_index(2:end)-1); allendssn.winter.exp.Zoo.N15 = output.exp.Zoo.N15(all_EW_index(2:end))-output.exp.Zoo.N15(all_SS_index(2:end)-1);
allendssn.summer.exp.Tot.N14(2:MI.ModelLength) = output.exp.Tot.N14(all_ES_index(2:end))-output.exp.Tot.N14(all_SS_index(2:end)-1); allendssn.winter.exp.Tot.N14 = output.exp.Tot.N14(all_EW_index(2:end))-output.exp.Tot.N14(all_SS_index(2:end)-1);
allendssn.summer.exp.Tot.N15(2:MI.ModelLength) = output.exp.Tot.N15(all_ES_index(2:end))-output.exp.Tot.N15(all_SS_index(2:end)-1); allendssn.winter.exp.Tot.N15 = output.exp.Tot.N15(all_EW_index(2:end))-output.exp.Tot.N15(all_SS_index(2:end)-1);

    allendssn.summer.exp.Dtm.Conc = allendssn.summer.exp.Dtm.N14+allendssn.summer.exp.Dtm.N15; allendssn.summer.exp.Dtm.d15N = (allendssn.summer.exp.Dtm.N15./allendssn.summer.exp.Dtm.N14/Rair-1)*1000;
    allendssn.summer.exp.Fru.Conc = allendssn.summer.exp.Fru.N14+allendssn.summer.exp.Fru.N15; allendssn.summer.exp.Fru.d15N = (allendssn.summer.exp.Fru.N15./allendssn.summer.exp.Fru.N14/Rair-1)*1000;
    allendssn.summer.exp.Zoo.Conc = allendssn.summer.exp.Zoo.N14+allendssn.summer.exp.Zoo.N15; allendssn.summer.exp.Zoo.d15N = (allendssn.summer.exp.Zoo.N15./allendssn.summer.exp.Zoo.N14/Rair-1)*1000;
    allendssn.summer.exp.Tot.Conc = allendssn.summer.exp.Tot.N14+allendssn.summer.exp.Tot.N15; allendssn.summer.exp.Tot.d15N = (allendssn.summer.exp.Tot.N15./allendssn.summer.exp.Tot.N14/Rair-1)*1000;
    allendssn.winter.exp.Dtm.Conc = allendssn.winter.exp.Dtm.N14+allendssn.winter.exp.Dtm.N15; allendssn.winter.exp.Dtm.d15N = (allendssn.winter.exp.Dtm.N15./allendssn.winter.exp.Dtm.N14/Rair-1)*1000;
    allendssn.winter.exp.Fru.Conc = allendssn.winter.exp.Fru.N14+allendssn.winter.exp.Fru.N15; allendssn.winter.exp.Fru.d15N = (allendssn.winter.exp.Fru.N15./allendssn.winter.exp.Fru.N14/Rair-1)*1000;
    allendssn.winter.exp.Zoo.Conc = allendssn.winter.exp.Zoo.N14+allendssn.winter.exp.Zoo.N15; allendssn.winter.exp.Zoo.d15N = (allendssn.winter.exp.Zoo.N15./allendssn.winter.exp.Zoo.N14/Rair-1)*1000;
    allendssn.winter.exp.Tot.Conc = allendssn.winter.exp.Tot.N14+allendssn.winter.exp.Tot.N15; allendssn.winter.exp.Tot.d15N = (allendssn.winter.exp.Tot.N15./allendssn.winter.exp.Tot.N14/Rair-1)*1000;
    
end