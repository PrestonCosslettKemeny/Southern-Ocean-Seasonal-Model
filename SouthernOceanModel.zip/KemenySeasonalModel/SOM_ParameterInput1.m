% ONE SET OF PARAMETERS TRYING TO FIT THE MODERN, INTERGLACIAL OCEAN
MI.PI = 1;

% MODEL TIME PARAMETERS
MI.ModelLength  = 150;                            % (y)        - Length of the simulation
MI.SummerSeason = 182;                            % (d)        - Length of the summer season
MI.WinterSeason = 365-182;                        % (d)        - Length of the winter season
MI.MLDSummer    = 50;                             % (m)        - Depth of ANZ summer mixed layer
MI.MLDWinter    = 175;                            % (m)        - Depth of ANZ winter mixed layer

% ISOTOPE REFERENCE
MI.Rair        = 0.0036765;                       % (-)        - 15N/14N ratio in AIR
MI.CDWd15N  = 4.74; % 4.7408;                     % (per mil)  - d15N of CDW (fitPK.cdw.d15N)
MI.CDWConc = 33.5; %32.617*1.027;                 % (mmol/m^3) - (NO3-) in CDW (fitPK.cdw.rcon ~ 32.617 umol/kg)

% MODEL SPACE PARAMETERS AND BOUDARY CONDITIONS
Rcdw = MI.Rair*(MI.CDWd15N/1000+1);               % (-)        - 15N/14N in CDW
MI.CDWN14  = MI.CDWConc/(1+Rcdw);                 % (mmol/m^3) - 14N NO3 in CDW
MI.CDWN15  = MI.CDWConc-MI.CDWN14;                % (mmol/m^3) - 15N NO3 in CDW

% DECLARE THE SEASONAL TARGETS
% The key vector is fitPK.sum.unt (made in KemenyFind3Points2)
% The concentrations are roudned to the nearest tenth, 
% the delt a values to the nearest hundreth
MI.endsummerTminconc = round(29.193*1.027,1);     % (mmol/m^3) - NO3 in summertime Tmin (fitPK.tmn.rcon =  29.193 umol/kg);
MI.endsummerTmind15N = round(5.0535,2);           % (per mil)  - d15N in summertime Tmin (fitPK.tmn.d15N = 5.0535);
MI.endsummersurfconc = round(24.693*1.027,1);     % (mmol/m^3) - NO3 in summertime surface (fitPK.srf.rcon =  24.693 umol/kg);
MI.endsummersurfd15N = round(5.9982,2);           % (per mil)) - d15N in summertime surface(fitPK.srf.d15N = 5.9982);
% The experimental data are reported in umol/kg, so multiply values by
% 1.027 (density of seawater) for uM = mmol/m^3.

% AREAS
% Calculated from Orsi et al (1995) front positions using spherical caps
MI.ANZArea = 1.8e13;                              % (m^2)      - Area between PF and SB, calculated from Orsi
Sv =  1/(24*60*60*1e6);                           % ((Sv*d)/(m^3)) - For scaling into Sverdrups 

% EKMAN UPWELLING
MI.EkmanCDWTransport = 20/Sv;                     % (m^3/d)    - Summer CDW Ekman transport of NO3

% SEASONAL MIXING
MI.MixTmnCDWBnd                    = 20/Sv;       % (m^3/d)    - Tmin/CDW mixing of NO3
MI.MixTmnSrfWinter                 = 300/Sv;      % (m^3/d)    - Tmin/surface mixing in winter of NO3
MI.MixTmnSrfSummer                 = 0/Sv;        % (m^3/d)    - Tmin/surface mixing in summer of NO3

% BIOMASS REMINERALIZATION
MI.BiomassRemineralizationFraction = 0.10;        % (-)        - Sinking diatoms remineralized in Tmin
MI.BiomassRemineralizationEpsilon  = 0;           % (per mil)  - Isotope effect of remineralizing sinking organic matter

% PENNATE AND CENTRIC DIATOMS
MI.DtmVmax                         =  0.057;      % (mmol/m^3/d) - Consumption term in MM kinetics for NO3 assimilation
MI.DtmKnNO3                        =  0.50;       % (mmol/m^3) - Half-saturation constant in MM for NO3 assimilation
MI.DtmNO3UptakeEpsilon             = -5.85;       % (per mil)  - Isotope effect of NO3 consumption. Go as low 5.6. Try 5.8, 5.9 (just to look better)
MI.DtmFrustFrac                    =  0.001;      % (-)        - Nitrogen bound within diatom frustule to total B
MI.DtmSink                         =  0.03;       % (1/d)      - Daily diatom sinking rate
MI.DtmGrowDayStart                 =  0;          % (d)        - First day centric diatoms should grow
MI.DtmGrowDayEnd                   =  90;         % (d)        - Last day centric diatoms should grow

% ZOOPLANKTON           
MI.ZooConsumptionDtm               =  0.03;       % (1/d)      - Diatom assimilated each day
MI.ZooConsumptionEpsilon           =  0.00;       % (per mil)  - Isotope effect of diatom consumption
MI.ZooConsumptionNDm               =  0.17;       % (1/d)      - Non-diatom assimilated each day
MI.ZooNH4Production                =  0.50;       % (1/d)      - NH4+ production rate
MI.ZooNH4ProductionEpsilon         =  -3.00;      % (per mil)  - Isotope effect of NH4 production
MI.ZooDigestiveFraction            =  0.95;       % (-)        - Fraction of material fed to zooplankton than is metabolized
MI.ZooDigestiveEpsilon             =  -3.00;      % (per mil)  - Isotope effect of zooplankton metabolism

% AMMONIUM 
MI.NH4SrfRenitrificationSummer     =  0.00;       % (1/d)      - Rate of summertime nitrification
MI.NH4SrfRenitrificationWinter     =  0.05;       % (1/d)      - Rate of wintertime nitrification
MI.NH4TmnRenitrification           =  0.05;       % (1/d)      - Rate of wintertime nitrification
MI.NH4NitrificationEpsilon         = -15;         % (per mil)  - Isotope effect of wintertime nitrification

% NON-DIATOM PHYTOPLANKTON
MI.NDmNH4ConsumptionSummer         =  0.40;       % (1/d)      - Rate of NH4 consumption by non-diatom phytoplankton
MI.NDmUptakeEpsilon                =  0.00;       % (per mil)  - Isotope effect of NH4 uptake by non-diatom phytoplankton
MI.NDmToNH4                        =  0.03;       % (1/d)      - Rate of NH4 release by non-diatom phytoplankton
