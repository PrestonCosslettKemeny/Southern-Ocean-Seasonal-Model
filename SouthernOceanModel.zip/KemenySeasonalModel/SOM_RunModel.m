function [output steady endssn allendssn N0 MB ODEtype] = SOM_RunModel(MI,RunType)

% This function runs the model defined in SOM_MasterScript. 

%% DEFINE ADDITIONAL MODEL PARAMETERS
N0 = SOM_InitialConditions; % Initial model conditions
L = MI.ModelLength; % Length of model

% Determine model resolution and time points of interest
if isequal(RunType,'NormRes')
T = [0:1/365:L-1  L-1+1/24/365:1/24/365:L]*365;
options = odeset('Stats','off'); 
elseif isequal(RunType,'HighRes')
T = [0:1/365/24:L]*365; 
options = odeset('Stats','off','RelTol',1e-6,'AbsTol',1e-12); 
elseif isequal(RunType,'AltRes')
    % This is an alternative setting for exploring 
    % other ode solver options (such as 'MaxStep')
T = [0:1/365/24:L]*365;    
options = odeset('Stats','off','AbsTol',1e-10,'RelTol',1e-12); 
end

%% RUN THE MODEL
[t,Nf,S] = ode15s('SOM_SeasonalModel',T,N0,options,MI); ODEtype = 'ODE15s';
%[t,Nf,S] = ode23('SOM_SeasonalModel',T,N0,options,MI); ODEtype = 'ODE23';

% The name of the model is "SOM_SeasonalModel".
    % T is a series of requested time points
    % N0 is the initial condition
    % options are the ode solver options 
    % MI are the simulation variables

%% PROCESS MODEL RESULTS

% Turn any NaN+i*NaN into NaN
Nf(isnan(Nf))=NaN; 

if length(t)==length(T)    
    [output steady endssn allendssn] = SOM_OrganizeModelResults(t,Nf,MI);
    % Break model results in manipulable data structures 
       
else
    % If the model goes in a region of parameter space where 
    % it returns very few timesteps, the output should be NaN.. 
    % In this case, display a warning that the model failed to 
    % run correctly.
    output = NaN;
    steady = NaN;
    endssn = NaN;
    allendssn = NaN;
    display('Model time does not match input time. Model did not run to completion!!!')
end

SOM_TestMassConservation
% Test for mass conservation during each run of the model. 
% If mass was highly conserved in the model, the variable "MB"
% will equal 1. If not, the variable "MB" will equal 0.

end