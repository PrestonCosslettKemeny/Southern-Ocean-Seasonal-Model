function dN = SOM_SeasonalModel(T,N,options,MI)

% This script is a series of differential equations describing a
% seasonally-resolved model of nitrogen isotope dynamics in the 
% upper water column of the Southern Ocean.

%% VARIABLE ASSIGNMENT
SOM_CalculateInputVariables; % Break MI into usable variables
SOM_DeclareVariableIndex;    % Declare the index positions of variables
Sv =  1/(24*60*60*1e6);      % A usefull conversion factor for debugging
allNaN = 0;                  % For converting all values to NaN 

% SUMMER CONDITIONS
if rem(T,365)<SummerSeason   
    IsSummer               = 1;                             % Index of whether it is summertime conditions
    MixTmnSrf              = MixTmnSrfSummer;               % Tmin/Surface mixing during the summer
    NDmNH4Consumption      = NDmNH4ConsumptionSummer;       % NH4+ consumption rate by non-diatoms in summer
    NH4SrfRenitrification  = NH4SrfRenitrificationSummer;   % Surface NH4+ nitrification rate in summer
        
    % DIATOM GROWTH PARAMETERS
    if rem(T,365)>=DtmGrowDayStart & rem(T,365)<DtmGrowDayEnd 
         DtmVp = DtmVmax;                                   % Identify if this is a time step where diatoms grow
    else DtmVp = 0;                                         % If not, diatoms do not assimilate NO3-
    end       

% WINTER CONDITIONS    
else 
    IsSummer               = 0;                             % Index of whether it is summertime conditions
    MixTmnSrf              = MixTmnSrfWinter;               % Tmin/Surface mixing during the winter
    NDmNH4Consumption      = 0;                             % NH4+ consumption rate by non-diatoms in winter
    NH4SrfRenitrification  = NH4SrfRenitrificationWinter;   % Surface NH4+ nitrification rate in winter
    DtmVp                  = 0;                             % Diatoms do not assimilate NO3- in winter
end


%% MODEL ITERATION

% Units of volume flux are m^3/day
% Units of concentration are mmol N / m^3
% Units of export production are mmol N / m^2
% Units of mass balance are mmol N

% 1: SURFACE NO3 N14
    dN(iSrfNO3N14) = - MixTmnSrf/SrfVol*N(iSrfNO3N14) + MixTmnSrf/SrfVol*N(iTmnNO3N14)+...                                                   %  Mix Srf and Tmin for 14N-NO3
                     - EkmanCDWTransport/SrfVol*N(iSrfNO3N14)+...                                                                            %  Ekman upwelling of 14N-NO3 from the surface
                     + EkmanCDWTransport/SrfVol*N(iTmnNO3N14)+...                                                                            %  Ekman upwelling of 14N-NO3 from the Tmin
                     - DtmVp*N(iSrfNO3N14)/(N(iSrfNO3N14)+DtmKnNO3)+...                                                                      %  Removal of 14N-NO3 for diatom growth
                     + NH4SrfRenitrification*N(iSrfNH4N14);                                                                                  %  Addition of 14N-NO3 from 14N-NH4 nitrification              

% 2: SURFACE NO3 N15     
    dN(iSrfNO3N15) = - MixTmnSrf/SrfVol*N(iSrfNO3N15) + MixTmnSrf/SrfVol*N(iTmnNO3N15)+...                                                   %  Mix Srf and Tmin for 15N-NO3
                     - EkmanCDWTransport/SrfVol*N(iSrfNO3N15)+...                                                                            %  Ekman upwelling of 15N-NO3 from the surface
                     + EkmanCDWTransport/SrfVol*N(iTmnNO3N15)+...                                                                            %  Ekman upwelling of 15N-NO3 from the Tmin
                     - SOM_Calculate15NFlux(N(iSrfNO3N14),N(iSrfNO3N15),DtmVp*N(iSrfNO3N14)/(N(iSrfNO3N14)+DtmKnNO3),DtmNO3UptakeAlpha)+...  %  Removal of 15N-NO3 for diatom growth
                     + SOM_Calculate15NFlux(N(iSrfNH4N14),N(iSrfNH4N15),N(iSrfNH4N14)*NH4SrfRenitrification,NH4NitrificationAlpha);          %  Addition of 15N-NO3 from 15N-NH4 nitrification            
        
% 3: TEMPERATURE MINIMUM NO3 N14 
    dN(iTmnNO3N14) = - (MixTmnCDWBnd+MixTmnSrf)/TmnVol*N(iTmnNO3N14) + MixTmnSrf/TmnVol*N(iSrfNO3N14) + MixTmnCDWBnd/TmnVol*CDWN14 +...      %  Mix Tmin, BDW, Srf for NO3 14N      
                     - EkmanCDWTransport/TmnVol*N(iTmnNO3N14)+...                                                                            %  Ekman upwelling of 14N-NO3 from the Tmin
                     + EkmanCDWTransport/TmnVol*CDWN14 +...                                                                                  %  Ekman upwelling of 14N-NO3 from CDW
                     + N(iTmnNH4N14)*NH4TmnRenitrification;                                                                                  %  Wintertime 14N-NH4 nitrification
            
% 4: TEMPERATURE MINIMUM NO3 N15 
    dN(iTmnNO3N15) = - (MixTmnCDWBnd+MixTmnSrf)/TmnVol*N(iTmnNO3N15) + MixTmnSrf/TmnVol*N(iSrfNO3N15) + MixTmnCDWBnd/TmnVol*CDWN15+...       %  Mix Tmin, BDW, Srf for NO3 15N      
                     - EkmanCDWTransport/TmnVol*N(iTmnNO3N15)+...                                                                            %  Ekman upwelling of 145-NO3 from the Tmin
                     + EkmanCDWTransport/TmnVol*CDWN15+...                                                                                   %  Ekman upwelling of 15N-NO3 from CDW
                     + SOM_Calculate15NFlux(N(iTmnNH4N14),N(iTmnNH4N15),N(iTmnNH4N14)*NH4TmnRenitrification,NH4NitrificationAlpha);          %  Wintertime 15N-NH4 nitrification
        
% 5: SURFACE NH4 N14
    dN(iSrfNH4N14) = - MixTmnSrf/SrfVol*N(iSrfNH4N14) + MixTmnSrf/SrfVol*N(iTmnNH4N14)+...                                                   %  Mix Srf and Tmin for 14N-NH4
                     - EkmanCDWTransport/SrfVol*N(iSrfNH4N14) +...                                                                           %  Ekman upwelling of 14N-NH4 from the surface
                     + EkmanCDWTransport/SrfVol*N(iTmnNH4N14)+...                                                                            %  Ekman upwelling of 14N-NH4 from the Tmin
                     + N(iSrfZooN14)*ZooNH4Production+...                                                                                    %  Addition of 14N-NH4 from zooplankton
                     - N(iSrfNH4N14)*NH4SrfRenitrification+...                                                                               %  Remove 14N-NH4 for nitrification    
                     - N(iSrfNH4N14)*NDmNH4Consumption+...                                                                                   %  Remove 14N-NH4 for non-diatom phytoplankton growth
                     + N(iSrfNDmN14)*NDmToNH4;                                                                                               %  Addition of 14N-NH4 from non-diatom phytoplankton    

% 6: SURFACE NH4 N15
    dN(iSrfNH4N15) = - MixTmnSrf/SrfVol*N(iSrfNH4N15) + MixTmnSrf/SrfVol*N(iTmnNH4N15)+...                                                   %  Mix Srf and Tmin for 15N-NH4 
                     - EkmanCDWTransport/SrfVol*N(iSrfNH4N15) +...                                                                           %  Ekman upwelling of 15N-NH4 from the surface
                     + EkmanCDWTransport/SrfVol*N(iTmnNH4N15)+...                                                                            %  Ekman upwelling of 15N-NH4 from the Tmin
                     + SOM_Calculate15NFlux(N(iSrfZooN14),N(iSrfZooN15),N(iSrfZooN14)*ZooNH4Production,ZooNH4ProductionAlpha) +...           %  Addition of 15N-NH4 from zooplankton
                     - SOM_Calculate15NFlux(N(iSrfNH4N14),N(iSrfNH4N15),N(iSrfNH4N14)*NDmNH4Consumption,NDmUptakeAlpha) +...                 %  Remove 15N-NH4 for non-diatom phytoplankton growth
                     - SOM_Calculate15NFlux(N(iSrfNH4N14),N(iSrfNH4N15),N(iSrfNH4N14)*NH4SrfRenitrification,NH4NitrificationAlpha) +...      %  Remove 15N-NH4 for nitrification 
                     + N(iSrfNDmN15)*NDmToNH4;                                                                                               %  Addition of 15-NH4 from non-diatom phytoplankton                                                 

% Separate new diatom growth into biomass and frustule components
N14T = DtmVp*N(iSrfNO3N14)/(N(iSrfNO3N14)+DtmKnNO3);                                                                                         %  14N taken up from solution
N15T = SOM_Calculate15NFlux(N(iSrfNO3N14),N(iSrfNO3N15),DtmVp*N(iSrfNO3N14)/(N(iSrfNO3N14)+DtmKnNO3),DtmNO3UptakeAlpha);                     %  15N taken up from solution
R = DtmFrustFrac;       % The fraction of total N in the diatom furstule
alphaFruBio = 1.0028;   % The desired fractionation between frustule and biomass

% Split new growth between diatom biomass and diatom frustule and biomass 
% (equations derived in supplement S1)
a = 1-alphaFruBio;
b = N14T + (alphaFruBio-1)*R*(N14T+N15T)+alphaFruBio*N15T;
c = -alphaFruBio*N15T*R*(N14T+N15T);
N15_frustule = (-b+sqrt(b^2-4*a*c))/(2*a);
N14_frustule = R*(N14T+N15T)-N15_frustule;
N15_dtmbiomass = N15T - N15_frustule;
N14_dtmbiomass = N14T - (R*(N14T+N15T)-N15_frustule);
    % (N15_frustule+N14_frustule)/(N15T+N14T)
    % (N15_frustule/N14_frustule)/(N15_dtmbiomass/N14_dtmbiomass)
    % 1000*(N15_frustule/N14_frustule/Rair-1)-1000*(N15_dtmbiomass/N14_dtmbiomass/Rair-1)
    % N15T - N15_frustule - N15_dtmbiomass
    % N14T - N14_frustule - N14_dtmbiomass

if N15_frustule < 0 | N15_dtmbiomass < 0 | N14_frustule < 0 | N14_dtmbiomass < 0
    display('ERROR: Negative concentration when seperating diatoms growth between biomass and frustule. Values replaced with NaN!');
    N15_frustule = NaN; N15_dtmbiomass = NaN; N14_frustule = NaN; N14_dtmbiomass = NaN;
    dN(:) = NaN; allNaN = 1;
end                 
             
% 25: DIATOM FRUSTULE N14
    dN(iSrfDtmFrustN14) =  + N14_frustule + ...                                                                                              %  Addition of 14N into the diatom frustule in the water column
                           - N(iSrfDtmFrustN14)*(DtmSink+ZooConsumptionDtm);                                                                 %  Loss of 14N from the diatom frustule in the water column
    
% 26: DIATOM FRUSTULE N15
    dN(iSrfDtmFrustN15) = + N15_frustule + ...                                                                                               %  Addition of 15N into the diatom frustule in the water column
                          - N(iSrfDtmFrustN15)*(DtmSink+ZooConsumptionDtm);                                                                  %  Loss of 15N from the diatom frustule in the water column

% Calculate the amount of N lost from biomass on each timestep
DtmSink14N = N(iSrfDtmN14)*DtmSink;                                                                                                          %  14N N in sinking diatom biomass  
DtmSink15N = N(iSrfDtmN15)*DtmSink;                                                                                                          %  15N N in sinking diatom biomass
    
% 7: DIATOM N14
    dN(iSrfDtmN14) = + N14_dtmbiomass +...                                                                                                   %  Addition of 14N-N to diatoms
                     - N(iSrfDtmN14)*ZooConsumptionDtm+...                                                                                   %  Removal of 14N-N from zooplankton consumption                 
                     - DtmSink14N;                                                                                                           %  Sinking diatom 14N-N
           
% 8: DIATOM N15
    dN(iSrfDtmN15) = + N15_dtmbiomass +...                                                                                                   %  Addition of 15-N to diatoms
                     - SOM_Calculate15NFlux(N(iSrfDtmN14),N(iSrfDtmN15),N(iSrfDtmN14)*ZooConsumptionDtm,ZooConsumptionAlphaDtm) +...         %  Removal of 15N-N from zooplankton consumption                 
                     - DtmSink15N;                                                                                                           %  Sinking diatom 15N-N
                                  
% 9: ZOOPLANKTON N14 
% 10: ZOOPLANKTON N15
    % STEP 1: GATHER FOOD
    FoodN14 = + N(iSrfDtmN14)*ZooConsumptionDtm+...                                                                                          %  Addition of 14N-N to zooplanktons from diatoms
              + N(iSrfNDmN14)*ZooConsumptionNDm;                                                                                             %  Addition of 14N-N to zooplanktons from non-diatom phytoplankton
              
    FoodN15 = + SOM_Calculate15NFlux(N(iSrfDtmN14),N(iSrfDtmN15),N(iSrfDtmN14)*ZooConsumptionDtm,ZooConsumptionAlphaDtm)  +...               %  Addition of 145-N to zooplanktons from diatoms
              + N(iSrfNDmN15)*ZooConsumptionNDm;                                                                                             %  Addition of 15N-N to zooplanktons from non-diatom phytoplankton 
                     
    DigestedAdditionN14 = FoodN14*ZooDigestiveFraction;
    DigestedAdditionN15 = SOM_Calculate15NFlux(FoodN14,FoodN15,FoodN14*ZooDigestiveFraction,ZooDigestiveAlpha);
    
    FecalN14 = FoodN14-DigestedAdditionN14;
    FecalN15 = FoodN15-DigestedAdditionN15;

    % STEP 2: Release ammonium
    NH4release_N14 = N(iSrfZooN14)*ZooNH4Production;                                                                                         %  Remove Zooplankton 14N-N for NH4
    NH4release_N15 = SOM_Calculate15NFlux(N(iSrfZooN14),N(iSrfZooN15),N(iSrfZooN14)*ZooNH4Production,ZooNH4ProductionAlpha);                 %  Remove Zooplankton 15N-N for NH4
    
    % 9: ZOOPLANKTON N14
    dN(iSrfZooN14) = DigestedAdditionN14 - NH4release_N14;
    % 10: ZOOPLANKTON N15
    dN(iSrfZooN15) = DigestedAdditionN15 - NH4release_N15;    
      
% 11: NON-DIATOM PHYTOPLANKTON N14
    dN(iSrfNDmN14) = + N(iSrfNH4N14)*NDmNH4Consumption+...                                                                                   %  Add 14N-NH4 to NDm
                     - N(iSrfNDmN14)*ZooConsumptionNDm+...                                                                                   %  Remove NDm 14N-N
                     - N(iSrfNDmN14)*NDmToNH4;                                                                                               %  Remove NDm 14N-N

% 12: NON-DIATOM PHYTOPLANKTON N15
    dN(iSrfNDmN15) = + SOM_Calculate15NFlux(N(iSrfNH4N14),N(iSrfNH4N15),N(iSrfNH4N14)*NDmNH4Consumption,NDmUptakeAlpha) +...                 %  Add 15N-NH4 to NDm 
                     - N(iSrfNDmN15)*ZooConsumptionNDm+...                                                                                   %  Remove NDm 15N-N
                     - N(iSrfNDmN15)*NDmToNH4;                                                                                               %  Remove NDm 15N-N
                                           
% 17: TEMPERATURE MINIMUM NH4 N14 
    dN(iTmnNH4N14) = - (MixTmnCDWBnd+MixTmnSrf)/TmnVol*N(iTmnNH4N14) + MixTmnSrf/TmnVol*N(iSrfNH4N14) + ...                                  %  Mix Tmin, BDW, Srf for 14N-NH4       
                     - EkmanCDWTransport/TmnVol*N(iTmnNH4N14) + ...                                                                          %  Ekman upwelling of 14N-NH4 from the Tmin
                     - N(iTmnNH4N14)*NH4TmnRenitrification+...                                                                               %  Remove 14N-NH4 for nitrification              
                     + SrfVol/TmnVol*(BiomassRemineralizationFraction*FecalN14)+...                                                          %  Remineralization of fecal pellet N14-N                      
                     + SrfVol/TmnVol*(BiomassRemineralizationFraction*DtmSink14N);                                                           %  Remineralization of sinking diatom N14-N                      

% 18: TEMPERATURE MINIMUM NH4 N15         
    dN(iTmnNH4N15) = - (MixTmnCDWBnd+MixTmnSrf)/TmnVol*N(iTmnNH4N15) + MixTmnSrf/TmnVol*N(iSrfNH4N15) + ...                                  %  Mix Tmin, BDW, Srf for 15N-NH4          
                     - EkmanCDWTransport/TmnVol*N(iTmnNH4N15) + ...                                                                          %  Ekman upwelling of 15N-NH4 from the Tmin
                     - SOM_Calculate15NFlux(N(iTmnNH4N14),N(iTmnNH4N15),N(iTmnNH4N14)*NH4TmnRenitrification,NH4NitrificationAlpha)+...       %  Remove 15N-NH4 for nitrification 
                     + SrfVol/TmnVol*SOM_Calculate15NFlux(FecalN14,FecalN15,BiomassRemineralizationFraction*FecalN14,BiomassRemineralizationAlpha)+...    %  Remineralization of fecal pellet N15-N                      
                     + SrfVol/TmnVol*SOM_Calculate15NFlux(DtmSink14N,DtmSink15N,BiomassRemineralizationFraction*DtmSink14N,BiomassRemineralizationAlpha); %  Remineralization of sinking diatom N15-N                                                                
                                           
%-------------------------------------------------------------------------
%-------------------------------------------------------------------------
% FOR EXPORT, the exporting term has units of [mmol/m^3/day],
% so multiply by by MLD to get [mmol/m^2/day]
      
% 13: DIATOM EXPORT PRODUCTION N14
    dN(iExpDtmN14) = + MLDSummer * DtmSink14N*(1-BiomassRemineralizationFraction);

% 14: DIATOM EXPORT PRODUCTION N15
    dN(iExpDtmN15) = + MLDSummer * (DtmSink15N - SOM_Calculate15NFlux(DtmSink14N,DtmSink15N,BiomassRemineralizationFraction*DtmSink14N,BiomassRemineralizationAlpha));

% 23: DIATOM FRUSTULE EXPORT PRODUCTION N14
    dN(iExpDtmFrustN14) = + MLDSummer * N(iSrfDtmFrustN14)*(DtmSink+ZooConsumptionDtm);

% 24: DIATOM FRUSTULE EXPORT PRODUCTION N15
    dN(iExpDtmFrustN15) = + MLDSummer * N(iSrfDtmFrustN15)*(DtmSink+ZooConsumptionDtm);  
           
% 15: ZOOPLANKTON EXPORT PRODUCTION N14
    dN(iExpZooN14) = + MLDSummer * FecalN14 * (1-BiomassRemineralizationFraction);
    
% 16: ZOOPLANKTON EXPORT PRODUCTION N15
    dN(iExpZooN15) = + MLDSummer * (FecalN15 - SOM_Calculate15NFlux(FecalN14,FecalN15,BiomassRemineralizationFraction*FecalN14,BiomassRemineralizationAlpha));  
     
%-------------------------------------------------------------------------
%-------------------------------------------------------------------------
% The following reservoirs track the gross input and output of
% nitrogen in the model. Units are [m^3/day]*[mmol/m^3] = mmol(/day)

% 19: 14N INPUTS   
    dN(iInN14)  = + EkmanCDWTransport*CDWN14+...          % N14-NO3 entering the Tmin through Ekman pumping
                  + MixTmnCDWBnd*CDWN14;                  % N14-NO3 entering the Tmin through mixing
    
% 20: 15N INPUTS
    dN(iInN15)  = + EkmanCDWTransport*CDWN15+...          % N15-NO3 entering the Tmin through Ekman pumping
                  + MixTmnCDWBnd*CDWN15;                  % N15-NO3 entering the Tmin through mixing
    
% 21: 14N OUTPUTS
    dN(iOutN14) = + EkmanCDWTransport*N(iSrfNO3N14)...   % N14-NO3 leaving the surface ocean through Ekman pumping
                  + EkmanCDWTransport*N(iSrfNH4N14)...   % N14-NH4 leaving the surface ocean through Ekman pumping
                  + MixTmnCDWBnd*N(iTmnNO3N14)...        % N14-NO3 leaving the Tmin through mixing
                  + MixTmnCDWBnd*N(iTmnNH4N14);          % N14-NH4 leaving the Tmin through mixing
         
% 22: 15N OUTPUTS
    dN(iOutN15) = + EkmanCDWTransport*N(iSrfNO3N15)...   % N15-NO3 leaving the surface ocean through Ekman pumping
                  + EkmanCDWTransport*N(iSrfNH4N15)...   % N15-NH4 leaving the surface ocean through Ekman pumping
                  + MixTmnCDWBnd*N(iTmnNO3N15)     ...   % N15-NO3 leaving the Tmin through mixing
                  + MixTmnCDWBnd*N(iTmnNH4N15);          % N15-NH4 leaving the Tmin through mixing     
         
dN = dN'; % Reorient the vector of change 

% If the model did not run well, change all entires to NaN
if allNaN == 1
dN(:) = NaN; end

end     