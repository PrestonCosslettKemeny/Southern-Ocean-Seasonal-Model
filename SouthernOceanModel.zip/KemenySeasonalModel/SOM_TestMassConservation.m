% This script tests whether the Southern Ocean seasonal model is 
% conserving mass. The script accounts for all mass moving into and out
% of the system, and returns a variable "MB" with the status of 
% mass conservation. 

% Volume elements (used for converting concentrations
% to total amounts of N)
SrfArea = MI.ANZArea; 
SrfVOL = SrfArea*MI.MLDSummer;            
TmnVOL = SrfArea*(MI.MLDWinter-MI.MLDSummer);   

% First account for the 14N and 15N moving into and out
% of the model. These fluxes are calcualted within the
% model itself and are assigned to the "output" variable.
N14In = output.MB.OAZIn.N14; % input 14N  (mmol N)
N15In = output.MB.OAZIn.N15; % input 15N  (mmol N)
N14Ot = output.MB.OAZOt.N14; % output 14N (mmol N)
N15Ot = output.MB.OAZOt.N15; % output 15N (mmol N)                  

% Second, account for all of the 14N and 15N in the model's 
% N reservoirs at each point in time. 
allN14 = (output.NO3.Srf.N14*SrfVOL...  % (mmol/m^3*m^3) = (mmol N)
        + output.NO3.Tmn.N14*TmnVOL...
        + output.NH4.Srf.N14*SrfVOL...
        + output.NH4.Tmn.N14*TmnVOL...
        + output.Dtm.Srf.N14*SrfVOL...
        + output.Fru.Srf.N14*SrfVOL...
        + output.Zoo.Srf.N14*SrfVOL...        
        + output.NDm.Srf.N14*SrfVOL);  
allN15 = (output.NO3.Srf.N15*SrfVOL... % (mmol/m^3*m^3) = (mmol N)
        + output.NO3.Tmn.N15*TmnVOL...
        + output.NH4.Srf.N15*SrfVOL...
        + output.NH4.Tmn.N15*TmnVOL...
        + output.Dtm.Srf.N15*SrfVOL...
        + output.Fru.Srf.N15*SrfVOL...
        + output.Zoo.Srf.N15*SrfVOL...
        + output.NDm.Srf.N15*SrfVOL);   

% Third, account for the N exported from the system 
% in diatom biomass, frustules, and zooplankton fecal pellets.
Texptot14N = output.exp.Tot.N14*SrfArea; % (mmol/m^2*m^2) = (mmol N)
Texptot15N = output.exp.Tot.N15*SrfArea;
Texpdtm14N = output.exp.Dtm.N14*SrfArea;
Texpdtm15N = output.exp.Dtm.N15*SrfArea;
Texpdtmfrust14N = output.exp.Fru.N14*SrfArea;
Texpdtmfrust15N = output.exp.Fru.N15*SrfArea;
Texpzoo14N = output.exp.Zoo.N14*SrfArea;
Texpzoo15N = output.exp.Zoo.N15*SrfArea;

% The units of ouput production are often confusing. 
% Consider that dividing output by MLD would get back to
% a concentration, and then we would multiply by volume to
% get to mmol N, which is overall the same as multiplying 
% output by surface area.

% Fourth, consider the N in the system at the beginning 
% of the model run.
SOM_DeclareVariableIndex
iN14  = (N0(iSrfNO3N14)*SrfVOL... % (mmol/m^3*m^3) = (mmol N)
       + N0(iTmnNO3N14)*TmnVOL...
       + N0(iSrfNH4N14)*SrfVOL...
       + N0(iTmnNH4N14)*TmnVOL...
       + N0(iSrfDtmN14)*SrfVOL...
       + N0(iSrfDtmFrustN14)*SrfVOL...
       + N0(iSrfZooN14)*SrfVOL...        
       + N0(iSrfNDmN14)*SrfVOL);
iN15  = (N0(iSrfNO3N15)*SrfVOL...
       + N0(iTmnNO3N15)*TmnVOL...
       + N0(iSrfNH4N15)*SrfVOL...
       + N0(iTmnNH4N15)*TmnVOL...
       + N0(iSrfDtmN15)*SrfVOL...
       + N0(iSrfDtmFrustN15)*SrfVOL...
       + N0(iSrfZooN15)*SrfVOL...
       + N0(iSrfNDmN15)*SrfVOL); 
  
% Lastly, take the difference of N initially in the model
% + N that moves into the model from N that ends inside
% the model, N exported for the model, and N that leaves 
% the model during the simulation.    
            % enter  initial   output  in system  exported
MissingN14 = (N14In + iN14) - (N14Ot + allN14 + Texptot14N); % (mmol N)   
MissingN15 = (N15In + iN15) - (N15Ot + allN15 + Texptot15N); % (mmol N)   
EndMissingN14 = (N14In(end) + iN14) - (N14Ot(end) + allN14(end) + Texptot14N(end)); % (mmol N)   
EndMissingN15 = (N15In(end) + iN15) - (N15Ot(end) + allN15(end) + Texptot15N(end)); % (mmol N)   

% Final year: 
yearindex = find(output.day((output.day(end)/365-1)*365:end));

% Calculate the missing 14N and 15N as proportion of the N in the
% model at the end of the simulation. If this proportion it too high, 
% display that there is a mass balance problem. 
MissingN14f = EndMissingN14./allN14(end);
MissingN15f = EndMissingN15./allN15(end);
   % If the missing N were in the surface, it would be: (EndMissingN14+EndMissingN15)/SrfVOL 
if abs(MissingN14f)>1e-6; MB = 0; disp('AZ 14N IS NOT IN MASS BALANCE'); keyboard; end
if abs(MissingN15f)>1e-6; MB = 0; disp('AZ 15N IS NOT IN MASS BALANCE'); keyboard; end  
if isnan(MissingN14f) | isnan(MissingN15f); MB = 0; end
if abs(MissingN14f) < 1e-6 & abs(MissingN15f) < 1e-6
    MB = 1;
end
