% This function tests whether the model has actually attained a 
% steady state by the conclusion of the run

yrs = 25; xspace = 5; 

NO3TmnConcsum = allendssn.summer.NO3.Tmn.Conc(end-yrs:end);
NO3SrfConcsum = allendssn.summer.NO3.Srf.Conc(end-yrs:end);
NH4TmnConcsum = allendssn.summer.NH4.Tmn.Conc(end-yrs:end);
NH4SrfConcsum = allendssn.summer.NH4.Srf.Conc(end-yrs:end);
DtmConcsum    = allendssn.summer.Dtm.Srf.Conc(end-yrs:end);
ZooConcsum    = allendssn.summer.Zoo.Srf.Conc(end-yrs:end);
NDmConcsum    = allendssn.summer.NDm.Srf.Conc(end-yrs:end);

NO3Tmnd15Nsum = allendssn.summer.NO3.Tmn.d15N(end-yrs:end);
NO3Srfd15Nsum = allendssn.summer.NO3.Srf.d15N(end-yrs:end);
NH4Tmnd15Nsum = allendssn.summer.NH4.Tmn.d15N(end-yrs:end);
NH4Srfd15Nsum = allendssn.summer.NH4.Srf.d15N(end-yrs:end);
Dtmd15Nsum    = allendssn.summer.Dtm.Srf.d15N(end-yrs:end);
Zood15Nsum    = allendssn.summer.Zoo.Srf.d15N(end-yrs:end);
NDmd15Nsum    = allendssn.summer.NDm.Srf.d15N(end-yrs:end);

figure(1); clf; fs = 14; lw = 2;
s1 = subplot(7,2,1);   plot(NO3SrfConcsum,'linewidth',lw); ylabel('Srf NO3'); title('End-summer Concentration')
s2 = subplot(7,2,2);   plot(NO3Srfd15Nsum,'linewidth',lw); ylabel('Srf NO3'); title('End-summer \delta^{15}N')
s3 = subplot(7,2,3);   plot(NO3TmnConcsum,'linewidth',lw); ylabel('Tmin NO3');
s4 = subplot(7,2,4);   plot(NO3Tmnd15Nsum,'linewidth',lw); ylabel('Tmin NO3');
s5 = subplot(7,2,5);   plot(NH4SrfConcsum,'linewidth',lw);  ylabel('Srf NH4');
s6 = subplot(7,2,6);   plot(NH4Srfd15Nsum,'linewidth',lw);  ylabel('Srf NH4');
s7 = subplot(7,2,7);   plot(NH4TmnConcsum,'linewidth',lw);  ylabel('Tmin NH4');
s8 = subplot(7,2,8);   plot(NH4Tmnd15Nsum,'linewidth',lw); ylabel('Tmin NH4');
s9 = subplot(7,2,9);   plot(DtmConcsum,'linewidth',lw); ylabel('Dtm');
s10 = subplot(7,2,10); plot(Dtmd15Nsum,'linewidth',lw);  ylabel('Dtm');
s11 = subplot(7,2,11); plot(ZooConcsum,'linewidth',lw); ylabel('Zoo');
s12 = subplot(7,2,12); plot(Zood15Nsum,'linewidth',lw);  ylabel('Zoo');
s13 = subplot(7,2,13); plot(NDmConcsum,'linewidth',lw);  ylabel('NDm');
s14 = subplot(7,2,14); plot(NDmd15Nsum,'linewidth',lw);  ylabel('NDm');
set([s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12 s13 s14],'fontsize',fs);
set([s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12 s13 s14],'xlim',[0 yrs],...
    'xtick',[0:xspace:yrs],'xticklabel',[MI.ModelLength-yrs:xspace:MI.ModelLength]);
