function MI = SOM_UpdateInputParameters(MI,ChangeVariablesSame,Factor,itercounter)

% This function updates the value of MI in the
% variable "ChangeVariablesSame" by a given factor.

    for cv = 1:length(ChangeVariablesSame)
         oldval = eval(sprintf('MI.%s',cell2mat(ChangeVariablesSame(cv))));         
         MI = setfield(MI,ChangeVariablesSame{cv},oldval*Factor(itercounter));
    end
end