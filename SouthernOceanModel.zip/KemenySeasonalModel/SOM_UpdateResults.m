 function results = SOM_UpdateResults(EndssnCell,SteadyCell)
% This function calculates the end-season results from multiple model years.
 
for itercounter=1:length(EndssnCell)
    endssn = EndssnCell{itercounter};
    steady = SteadyCell{itercounter};
    
    % Water column N reservoirs
    results.winter.NO3.Srf.N14(itercounter)  = endssn.winter.NO3.Srf.N14;  results.summer.NO3.Srf.N14(itercounter)  = endssn.summer.NO3.Srf.N14;
    results.winter.NO3.Srf.N15(itercounter)  = endssn.winter.NO3.Srf.N15;  results.summer.NO3.Srf.N15(itercounter)  = endssn.summer.NO3.Srf.N15;
    results.winter.NO3.Srf.d15N(itercounter) = endssn.winter.NO3.Srf.d15N; results.summer.NO3.Srf.d15N(itercounter) = endssn.summer.NO3.Srf.d15N;
    results.winter.NO3.Srf.Conc(itercounter) = endssn.winter.NO3.Srf.Conc; results.summer.NO3.Srf.Conc(itercounter) = endssn.summer.NO3.Srf.Conc;
    results.winter.NO3.Tmn.N14(itercounter)  = endssn.winter.NO3.Tmn.N14;  results.summer.NO3.Tmn.N14(itercounter)  = endssn.summer.NO3.Tmn.N14;
    results.winter.NO3.Tmn.N15(itercounter)  = endssn.winter.NO3.Tmn.N15;  results.summer.NO3.Tmn.N15(itercounter)  = endssn.summer.NO3.Tmn.N15;
    results.winter.NO3.Tmn.d15N(itercounter) = endssn.winter.NO3.Tmn.d15N; results.summer.NO3.Tmn.d15N(itercounter) = endssn.summer.NO3.Tmn.d15N;
    results.winter.NO3.Tmn.Conc(itercounter) = endssn.winter.NO3.Tmn.Conc; results.summer.NO3.Tmn.Conc(itercounter) = endssn.summer.NO3.Tmn.Conc;
    results.winter.Dtm.Srf.N14(itercounter)  = endssn.winter.Dtm.Srf.N14;  results.summer.Dtm.Srf.N14(itercounter)  = endssn.summer.Dtm.Srf.N14;
    results.winter.Dtm.Srf.N15(itercounter)  = endssn.winter.Dtm.Srf.N15;  results.summer.Dtm.Srf.N15(itercounter)  = endssn.summer.Dtm.Srf.N15;
    results.winter.Dtm.Srf.d15N(itercounter) = endssn.winter.Dtm.Srf.d15N; results.summer.Dtm.Srf.d15N(itercounter) = endssn.summer.Dtm.Srf.d15N;
    results.winter.Dtm.Srf.Conc(itercounter) = endssn.winter.Dtm.Srf.Conc; results.summer.Dtm.Srf.Conc(itercounter) = endssn.summer.Dtm.Srf.Conc;
    results.winter.Fru.Srf.N14(itercounter)  = endssn.winter.Fru.Srf.N14;  results.summer.Fru.Srf.N14(itercounter)  = endssn.summer.Fru.Srf.N14;
    results.winter.Fru.Srf.N15(itercounter)  = endssn.winter.Fru.Srf.N15;  results.summer.Fru.Srf.N15(itercounter)  = endssn.summer.Fru.Srf.N15;
    results.winter.Fru.Srf.d15N(itercounter) = endssn.winter.Fru.Srf.d15N; results.summer.Fru.Srf.d15N(itercounter) = endssn.summer.Fru.Srf.d15N;
    results.winter.Fru.Srf.Conc(itercounter) = endssn.winter.Fru.Srf.Conc; results.summer.Fru.Srf.Conc(itercounter) = endssn.summer.Fru.Srf.Conc;    
    results.winter.NDm.Srf.N14(itercounter)  = endssn.winter.NDm.Srf.N14;  results.summer.NDm.Srf.N14(itercounter)  = endssn.summer.NDm.Srf.N14;
    results.winter.NDm.Srf.N15(itercounter)  = endssn.winter.NDm.Srf.N15;  results.summer.NDm.Srf.N15(itercounter)  = endssn.summer.NDm.Srf.N15;
    results.winter.NDm.Srf.d15N(itercounter) = endssn.winter.NDm.Srf.d15N; results.summer.NDm.Srf.d15N(itercounter) = endssn.summer.NDm.Srf.d15N;
    results.winter.NDm.Srf.Conc(itercounter) = endssn.winter.NDm.Srf.Conc; results.summer.NDm.Srf.Conc(itercounter) = endssn.summer.NDm.Srf.Conc;
    results.winter.Zoo.Srf.N14(itercounter)  = endssn.winter.Zoo.Srf.N14;  results.summer.Zoo.Srf.N14(itercounter)  = endssn.summer.Zoo.Srf.N14;
    results.winter.Zoo.Srf.N15(itercounter)  = endssn.winter.Zoo.Srf.N15;  results.summer.Zoo.Srf.N15(itercounter)  = endssn.summer.Zoo.Srf.N15;
    results.winter.Zoo.Srf.d15N(itercounter) = endssn.winter.Zoo.Srf.d15N; results.summer.Zoo.Srf.d15N(itercounter) = endssn.summer.Zoo.Srf.d15N;
    results.winter.Zoo.Srf.Conc(itercounter) = endssn.winter.Zoo.Srf.Conc; results.summer.Zoo.Srf.Conc(itercounter) = endssn.summer.Zoo.Srf.Conc;
    results.winter.NH4.Srf.N14(itercounter)  = endssn.winter.NH4.Srf.N14;  results.summer.NH4.Srf.N14(itercounter)  = endssn.summer.NH4.Srf.N14;
    results.winter.NH4.Srf.N15(itercounter)  = endssn.winter.NH4.Srf.N15;  results.summer.NH4.Srf.N15(itercounter)  = endssn.summer.NH4.Srf.N15;
    results.winter.NH4.Srf.d15N(itercounter) = endssn.winter.NH4.Srf.d15N; results.summer.NH4.Srf.d15N(itercounter) = endssn.summer.NH4.Srf.d15N;
    results.winter.NH4.Srf.Conc(itercounter) = endssn.winter.NH4.Srf.Conc; results.summer.NH4.Srf.Conc(itercounter) = endssn.summer.NH4.Srf.Conc;
    results.winter.NH4.Tmn.N14(itercounter)  = endssn.winter.NH4.Tmn.N14;  results.summer.NH4.Tmn.N14(itercounter)  = endssn.summer.NH4.Tmn.N14;
    results.winter.NH4.Tmn.N15(itercounter)  = endssn.winter.NH4.Tmn.N15;  results.summer.NH4.Tmn.N15(itercounter)  = endssn.summer.NH4.Tmn.N15;
    results.winter.NH4.Tmn.d15N(itercounter) = endssn.winter.NH4.Tmn.d15N; results.summer.NH4.Tmn.d15N(itercounter) = endssn.summer.NH4.Tmn.d15N;
    results.winter.NH4.Tmn.Conc(itercounter) = endssn.winter.NH4.Tmn.Conc; results.summer.NH4.Tmn.Conc(itercounter) = endssn.summer.NH4.Tmn.Conc;       
    results.winter.Nit.Srf.N14(itercounter)  = endssn.winter.Nit.Srf.N14;  results.summer.Nit.Srf.N14(itercounter)  = endssn.summer.Nit.Srf.N14;
    results.winter.Nit.Srf.N15(itercounter)  = endssn.winter.Nit.Srf.N15;  results.summer.Nit.Srf.N15(itercounter)  = endssn.summer.Nit.Srf.N15;
    results.winter.Nit.Srf.d15N(itercounter) = endssn.winter.Nit.Srf.d15N; results.summer.Nit.Srf.d15N(itercounter) = endssn.summer.Nit.Srf.d15N;
    results.winter.Nit.Srf.Conc(itercounter) = endssn.winter.Nit.Srf.Conc; results.summer.Nit.Srf.Conc(itercounter) = endssn.summer.Nit.Srf.Conc;
    results.winter.PaN.Srf.N14(itercounter)  = endssn.winter.PaN.Srf.N14;  results.summer.PaN.Srf.N14(itercounter)  = endssn.summer.PaN.Srf.N14;
    results.winter.PaN.Srf.N15(itercounter)  = endssn.winter.PaN.Srf.N15;  results.summer.PaN.Srf.N15(itercounter)  = endssn.summer.PaN.Srf.N15;
    results.winter.PaN.Srf.d15N(itercounter) = endssn.winter.PaN.Srf.d15N; results.summer.PaN.Srf.d15N(itercounter) = endssn.summer.PaN.Srf.d15N;
    results.winter.PaN.Srf.Conc(itercounter) = endssn.winter.PaN.Srf.Conc; results.summer.PaN.Srf.Conc(itercounter) = endssn.summer.PaN.Srf.Conc;
    
    % Declare max values
    results.max.Dtm.N14(itercounter) = max(steady.Dtm.Srf.N14);
    results.max.Dtm.N15(itercounter) = mean(steady.Dtm.Srf.N15(max(steady.Dtm.Srf.N14)==steady.Dtm.Srf.N14));
    results.max.Fru.N14(itercounter) = max(steady.Fru.Srf.N14);
    results.max.Fru.N15(itercounter) = mean(steady.Fru.Srf.N15(max(steady.Fru.Srf.N14)==steady.Fru.Srf.N14));  
    results.max.NDm.N14(itercounter) = max(steady.NDm.Srf.N14);
    results.max.NDm.N15(itercounter) = mean(steady.NDm.Srf.N15(max(steady.NDm.Srf.N14)==steady.NDm.Srf.N14));
    results.max.Zoo.N14(itercounter) = max(steady.Zoo.Srf.N14);
    results.max.Zoo.N15(itercounter) = mean(steady.Zoo.Srf.N15(max(steady.Zoo.Srf.N14)==steady.Zoo.Srf.N14));
    results.max.NH4.N14(itercounter) = max(steady.NH4.Srf.N14);  
    results.max.NH4.N15(itercounter) = mean(steady.NH4.Srf.N15(max(steady.NH4.Srf.N14)==steady.NH4.Srf.N14));
      
    % Export Production
    results.summer.exp.Dtm.N14 (itercounter) = endssn.summer.exp.Dtm.N14;  results.winter.exp.Dtm.N14 (itercounter) = endssn.winter.exp.Dtm.N14;    
    results.summer.exp.Dtm.N15 (itercounter) = endssn.summer.exp.Dtm.N15;  results.winter.exp.Dtm.N15 (itercounter) = endssn.winter.exp.Dtm.N15;
    results.summer.exp.Dtm.Conc(itercounter) = endssn.summer.exp.Dtm.Conc; results.winter.exp.Dtm.Conc(itercounter) = endssn.winter.exp.Dtm.Conc;
    results.summer.exp.Dtm.d15N(itercounter) = endssn.summer.exp.Dtm.d15N; results.winter.exp.Dtm.d15N(itercounter) = endssn.winter.exp.Dtm.d15N;
    results.summer.exp.Fru.N14 (itercounter) = endssn.summer.exp.Fru.N14;  results.winter.exp.Fru.N14 (itercounter) = endssn.winter.exp.Fru.N14;    
    results.summer.exp.Fru.N15 (itercounter) = endssn.summer.exp.Fru.N15;  results.winter.exp.Fru.N15 (itercounter) = endssn.winter.exp.Fru.N15;
    results.summer.exp.Fru.Conc(itercounter) = endssn.summer.exp.Fru.Conc; results.winter.exp.Fru.Conc(itercounter) = endssn.winter.exp.Fru.Conc;
    results.summer.exp.Fru.d15N(itercounter) = endssn.summer.exp.Fru.d15N; results.winter.exp.Fru.d15N(itercounter) = endssn.winter.exp.Fru.d15N;
    results.summer.exp.Zoo.N14 (itercounter) = endssn.summer.exp.Zoo.N14;  results.winter.exp.Zoo.N14 (itercounter) = endssn.winter.exp.Zoo.N14;
    results.summer.exp.Zoo.N15 (itercounter) = endssn.summer.exp.Zoo.N15;  results.winter.exp.Zoo.N15 (itercounter) = endssn.winter.exp.Zoo.N15;
    results.summer.exp.Zoo.Conc(itercounter) = endssn.summer.exp.Zoo.Conc; results.winter.exp.Zoo.Conc(itercounter) = endssn.winter.exp.Zoo.Conc;
    results.summer.exp.Zoo.d15N(itercounter) = endssn.summer.exp.Zoo.d15N; results.winter.exp.Zoo.d15N(itercounter) = endssn.winter.exp.Zoo.d15N;
    results.summer.exp.Tot.N14 (itercounter) = endssn.summer.exp.Tot.N14;  results.winter.exp.Tot.N14 (itercounter) = endssn.winter.exp.Tot.N14;
    results.summer.exp.Tot.N15 (itercounter) = endssn.summer.exp.Tot.N15;  results.winter.exp.Tot.N15 (itercounter) = endssn.winter.exp.Tot.N15;
    results.summer.exp.Tot.Conc(itercounter) = endssn.summer.exp.Tot.Conc; results.winter.exp.Tot.Conc(itercounter) = endssn.winter.exp.Tot.Conc;
    results.summer.exp.Tot.d15N(itercounter) = endssn.summer.exp.Tot.d15N; results.winter.exp.Tot.d15N(itercounter) = endssn.winter.exp.Tot.d15N;
          
end  
end
    